# TF_GNN — Stages 1–4, measured

State as of 2026-08-03, all numbers from
`artifacts/stage1/stage1_comparison.json`. Every arm was trained and scored on
**identical rows**, split by `split_id` from TigerGraph, with a paired bootstrap
on each difference. An interval touching zero has shown nothing, whatever the
point estimate reads.

---

## The data

| | |
|---|---|
| transactions loaded | **27,404,317** |
| assembled into the matrix | 22,505,700 |
| withheld as warm-up | 4,898,617 (split 0, below the first fold boundary) |
| train / val / test | 19,594,469 / 1,392,041 / 1,519,190 |
| fraud prevalence | 0.1402% / 0.1560% / **0.1293%** |
| feature snapshots | 6 forward-chaining builds (4 train folds + val + test) |

**Test is 36.4% inductive, and this is measured, not assumed.**
`manifest.json`'s `inductive_reach`: **5,287 of 12,868 test cards (41.1%)** and 50
of 462 merchants were never seen in training, affecting **552,579 of 1,519,190
test rows** — 35.6% via the card, 1.2% via the merchant. Validation is 11.8%.
Training saw 63,061 cards and 975 merchants.

Every result below is measured WITH those cold-start rows included, so 0.5631 and
436x base rate are not a score on the easy subset. D3d's ban on learnable per-node
ID embeddings is what makes those rows scoreable at all.

**The corpus and the graph are fixed.** One dataset, one schema, one load. Every
arm below is measured on exactly these rows — that is what makes the paired
bootstrap a comparison rather than four experiments. The counts are still read
from `assert_cardinality` / `assert_edge_stamp` at run time rather than from
prose, because a gate that recounts is what proves the constant held.

---

## Results

Test fraud prevalence is **0.1293%**, so random guessing scores 0.00129 AUC-PR.
The `vs random` column is what a business reader actually wants.

| arm | features | test AUC-PR | 95% interval | vs random | ROC-AUC | best_iter |
|---|---|---|---|---|---|---|
| raw | 19 | 0.1711 | [0.1560, 0.1886] | 132× | 0.9053 | 77 |
| + aggregates | 35 | 0.2051 | [0.1868, 0.2235] | 159× | 0.9219 | 70 |
| + graph | 51 | 0.2150 | [0.1961, 0.2320] | 166× | 0.9441 | — |
| **+ temporal** | **60** | **0.5631** | **[0.5412, 0.5840]** | **436×** | **0.9909** | 139 |
| + R-GCN embeddings | 179 | 0.1919 | [0.1756, 0.2094] | 149× | 0.9425 | 53 |
| R-GCN instead of graph | 163 | 0.1924 | [0.1768, 0.2149] | 149× | 0.9161 | 58 |
| + R-GCN pair score | 54 | 0.2161 | [0.1981, 0.2355] | 167× | 0.9486 | 57 |
| **+ TGN pair score** | **63** | **0.5635** | **[0.5423, 0.5888]** | **436×** | **0.9908** | 148 |
| + TGN embeddings | 260 | *not measured* | — | — | — | — |

| lift | value | 95% interval | P(better) | verdict |
|---|---|---|---|---|
| raw → aggregates | +0.0341 | [+0.0232, +0.0452] | 1.000 | significant |
| aggregates → graph | +0.0098 | [+0.0025, +0.0171] | 1.000 | significant, thin |
| graph → **temporal** | **+0.3482** | [+0.3253, +0.3698] | 1.000 | **the project's result** |
| graph → R-GCN embeddings | **−0.0231** | [−0.0325, −0.0129] | 0.000 | **significantly worse** |
| graph → R-GCN *instead of* graph | **−0.0226** | [−0.0327, −0.0116] | 0.000 | **significantly worse** |
| graph → R-GCN pair score | +0.0011 | [−0.0063, +0.0079] | 0.630 | **zero** |
| R-GCN embeddings → R-GCN pair score | **+0.0242** | [+0.0171, +0.0317] | 1.000 | **significant** |
| temporal → TGN pair score | +0.0003 | [−0.0077, +0.0078] | 0.460 | **zero** |

All eight arms are from one completed run (2026-08-04, `--exclude
raw_plus_temporal_embeddings`), on identical rows, with every interval a paired
percentile bootstrap on the *difference*.

### The GNN verdict, in three lifts

**Dilution is real and measurable.** Same encoder, same base, presentation changed
from 128 raw dimensions to three pair statistics: **+0.0242 [+0.0171, +0.0317]**,
P(better) = 1.000. A tree splits one dimension at a time and cannot form the dot
product a link-prediction decoder was trained to produce, so the raw dimensions
were actively harmful *as a presentation*.

**Information content, once dilution is removed, is zero.** `graph → R-GCN pair
score` is **+0.0011 [−0.0063, +0.0079]**, P(better) = 0.630. Not negative, not
positive — nothing. The R-GCN knows nothing about fraud that PageRank, entity
resolution and pair geography do not already say.

**The TGN is the same, which answers Stage 4b.** `temporal → TGN pair score` is
**+0.0003 [−0.0077, +0.0078]**, P(better) = 0.460. The 260-column arm would test
presentation, not information, and the information is what was in doubt. Its
message vector *is* the nine temporal columns XGBoost already receives losslessly.

**And the GNN cannot substitute for the graph features.** `R-GCN instead of graph`
drops PageRank, entity resolution and pair geography, keeping the 128 dimensions:
**−0.0226 [−0.0327, −0.0116]**, P(better) = 0.000. Engineered structure beats
learned structure here, significantly. Note also that `+ R-GCN embeddings` (0.1919)
and `R-GCN instead of graph` (0.1924) are statistically identical — adding the whole
graph block on top of the embeddings buys nothing, because the 128 dense columns
crowd out features worth +0.0098 on their own.

`raw_plus_temporal` and `raw_plus_embeddings` are **siblings** off
`raw_plus_graph` — the two cells of the {no-GNN, GNN} × {no-temporal, temporal}
design — so their lifts are directly comparable, and the pair-score arms are
siblings of the embedding arms off the same bases.

---

## Stage 1 — graph features help, modestly

**+0.0098 over aggregates**, interval clear of zero but with a lower bound of
just +0.0025. Real, and thinner than it first appeared: an earlier +0.0133 was
measured against a baseline still holding `t_year`, a monotone index correlated
with the temporal split and out of range at test. Removing it dropped `raw` by
0.011 and cost the graph arm some of its apparent margin. The current number is
the honest one.

Two things are worth knowing about how it was earned:

**23 of 74 columns are dead.** 7 are all-NaN (louvain, k-core and
card-interval families are disabled in config — expected). **16 are constant**:
`card_c_size`, `mer_c_size` and every `ccom_*`/`mcom_*` community statistic. That
is the WCC family collapsing into one giant component, which
`wcc_bipartite.gsql`'s own header predicted — a hub merchant reaching ~51% of
cards welds the bipartite graph together, and `min_txn_count: 2` was already the
retreat. **The +0.0098 was achieved with 51 effective features and no community
signal at all.**

**Top gains:** `cre_distinct_pii_count` 28.1%, `is_online` 21.9%,
`cat_total_amount` 7.5%, `pair_home_distance_km` 6.6%, `card_pagerank` 2.9%. The
entity-resolution and pair-geography features carry the graph arm; the
centrality and community families contribute little.

---

## Stage 2 — the R-GCN embeddings made it worse

**−0.0231, interval clear of zero, P(better) = 0.000.** Not noise.

The R-GCN itself trained fine — link-prediction loss fell 0.49 → 0.2669. It got
*good* at its objective and the embeddings *hurt* fraud detection. Three
compounding reasons:

1. **The objective is not the task.** Link prediction with balanced negatives
   teaches "which card–merchant pairs are plausible" — largely popularity and
   similarity. Nothing forces that to correlate with fraud.
2. **128 dense columns into a tree.** The information lives in the *relationship
   between* `h_card` and `h_merchant`; a tree can only threshold one dimension
   at a time. `best_iteration` fell 88 → 53 while the graph arm rose to 95, and
   **train** AUC-PR fell too — undertrained, not overfitted.
3. **The embeddings are static per snapshot** and carry no recency.

**No metric exists for the R-GCN itself.** It reports BCE loss only — no AUC-PR,
no ROC-AUC. So a zero lift cannot currently be distinguished from "the model
learned well and XGBoost already had the signal." That gap should be closed.

An untried fix with a clear mechanism: feed the **DistMult decoder score** —
`Σ(h_card · relation · h_merchant)`, one column — instead of 128 raw
dimensions. It is exactly "how plausible is this pair," which is what the model
was trained to produce and what a tree can actually split on.

---

## Stage 3 — per-row temporal features dominate

**+0.3482.** Nine features, computed in GSQL, from one card-anchored
gather → sort → forward scan:

| feature | definition |
|---|---|
| `row_pair_gap_seconds` | since this card last used **this merchant** (−1 = first visit) |
| `row_card_gap_seconds` | since this card's previous transaction (−1 = first) |
| `row_card_txn_count_1h` / `_24h` | prior transactions in the trailing window |
| `row_card_amount_24h` | prior spend in the trailing day |
| `row_card_tenure_seconds` | since this card's earliest transaction |

**Anchored at each row's own `unix_time`, never at a build cutoff.** A
cutoff-anchored window would encode which snapshot served the row, and would
inherit the fold geometry (train folds span ~4.9M ranks, val/test ~1.3M each).
Row-anchored, neither applies — and the table is build-independent, so it runs
once rather than six times.

### This was audited for leakage and is clean

The lift is 32× the entire graph family from a sixth as many features, so it was
attacked directly:

- **Ordering.** `event_seq` is *"a dense deterministic rank … ordered by
  (unix_time, id)"* (`schema.gsql:181`), so time order and split order agree.
- **HeapAccum direction** — the one thing that could have made every feature
  future-derived. TigerGraph's docs: `pop()` returns *"the top tuple"*, overflow
  drops *"the tuple which is last in the sorted order"*, and their worked
  example shows element order equals declared sort order. For `ut ASC`, `pop()`
  yields **ascending** time. Indices `[0, hi-1]` really are strictly earlier.
- **`@last_seen`** is written *after* the emit, so a row never sees itself.
- **The join** is on unique `event_seq` with a row-count assertion.

Two hypotheses were raised and both **falsified**: `row_card_tenure_seconds` as
a calendar proxy (it does not appear in the top 8), and descending sort order
(refuted by the docs).

### What the signal actually is

`row_pair_gap_seconds` is **16.6% of total gain**. Its −1 sentinel means *"this
card has never used this merchant before."* Measured on test:

```
first-visit share        7.97%
P(fraud | first visit)   0.801%      ← 11.3× enrichment
P(fraud | repeat)        0.071%
```

About **half the test fraud sits in 8% of the rows**. And 99.2% of first visits
are legitimate — if the generator were handing over the label this would be near
1.0. It is a strong, well-calibrated signal, and it is the textbook card-fraud
pattern: a compromised card gets used where the cardholder does not shop.

**Caveat for external validity, not correctness.** This is generated data. If
the generator assigns fraudulent transactions to randomly chosen merchants, the
magnitude measures the generator rather than fraud detection. The 11.3×
enrichment argues against the trivial version of that, but the number should
carry the caveat.

---

## Stage 4 — TGN, both heads measured

`artifacts/stage4/stage4_metrics_fraud.json` and `..._link.json`. 22,505,700
events, 68,618 cards, 1,027 merchants, 4,784 batches/epoch on CUDA, graph
attention on, 10 neighbours, 27 kept message columns (raw_dim 54), seed 13.

### 4a — the supervised at-arrival scorer (BREAKS D5)

`pos_weight` 712.3, early stopping on val AUC-PR at patience 5. Best epoch 14,
stopped at 19, ~6.2 min/epoch, ~68 ms/step.

**4a test: AUC-PR 0.3241, ROC-AUC 0.9805**, base rate 0.00129 -> **251x lift**.

| | test AUC-PR | lift over base |
|---|---|---|
| Stage 3 -- temporal features in XGBoost | **0.5631** | 436x |
| Stage 4a -- TGN as a direct scorer | 0.3241 | 251x |

**ROC-AUC 0.9805 should not be quoted on its own.** It exceeds the graph arm's
0.944, but at 0.129% prevalence ROC-AUC flatters every model. AUC-PR is the
honest metric here and it is the one that says 0.3241.

Superseded 4a numbers, kept so the trajectory is legible and because none of them
are comparable to each other -- the scoring regime moved twice and Stage 4 was
unseeded until 2026-08-03:

| run | test AUC-PR | why it does not stand |
|---|---|---|
| 3 epochs, 11 columns | 0.2797 | undertrained, before early stopping existed |
| memory-only (`--no-attention`), 11 columns | 0.3964 | uses no graph at all |
| 48 columns, 21 of them dead | 0.1888 | ~44 of 96 input slots carried nothing |
| attention on, 27 columns | 0.3824 | edge time feature was **constant**, and test was scored with memory that skipped the whole val split |

The constant-time-feature defect is worth naming precisely: `t - last_update` was
written the other way round, so `clamp(min=0)` zeroed every edge -- measured 0 of
20,507 edges carrying a non-zero value. Attention aggregated neighbour memory but
could not prefer recent neighbours over old ones, which is the whole reason it is
there.

### Four caveats that travel with any 4a number

**It breaks D5.** 4a trains on the fraud label -- a deliberate override by the
user on 2026-08-03, recorded in `stage4_metrics_fraud.json` as `breaks_d5: true`.
It is not comparable to Stage 2's arms on that axis and never enters the XGBoost
lift table.

**Its scoring regime differs.** Scoring keeps updating memory, because "catch it
when it happens" means the model has seen everything up to that moment. Memory
has consumed train and val when test is scored, and nothing later. An XGBoost arm
scores a frozen model. Both legitimate; different questions.

**It is not an architecture comparison on equal inputs.** The TGN sees 27
columns; `raw_plus_temporal` sees 57, including the 18 aggregates and the
calendar/target-encoding block the message vector deliberately excludes. Read
0.3241 vs 0.5631 as two feature sets, not two models. (The earlier version of
this gap was worse: 11 columns against 57, published as though the architectures
were being compared.)

**Val and test are measured in different regimes**, by roughly 0.046 AUC-PR.
PyG's `TGNMemory.forward` returns `_get_updated_memory()` in train mode and the
committed table in eval mode, so a train-mode pass and an eval-mode pass over the
same stream leave memory in different states. Early stopping selects on the
train-mode number; the reported test score is eval-mode, which is the
deployment-faithful one. Both are leak-free, but they are not the same
measurement. Measured on the link run: best epoch 10 reported val 0.6109, and the
same weights replayed in eval mode gave 0.5650.

### 4b — the D5-compliant link objective, and why the pretext task fails

`--objective link`, 15 epochs, best epoch 10, seed 13. Six per-build memory
snapshots exported to `artifacts/stage4/embeddings/`, 100 dims per node type,
`build_id` on every row so the join is on `(key, build_id)` like Stage 2's.

**4b test link AUC-PR 0.5624, ROC-AUC 0.5684 on a balanced target** -- chance is
0.5. Training loss reached 0.6688 against `-ln(0.5) = 0.6931`, i.e. **3.6% of the
way** from knowing nothing.

The cause is graph density, and it is a finding about the data rather than the
model. A card touches roughly **281 of 1,027 merchants**, so the bipartite graph
is about **27% dense** -- Cora is 0.074%, ogbl-collab 0.0023%. When a quarter of
all possible edges exist, "does this edge exist?" carries almost no information.
Uniform in-batch negatives compound it: ~27% of them are pairs the card really
uses, which caps even a perfect model near ROC-AUC 0.863. Measured 0.568 is well
below that ceiling, so most of the shortfall is absence of learnable structure,
not label noise.

**This reaches past Stage 4.** Link prediction is the D5-compliant pretext task in
*both* GNN stages, and the R-GCN also produced a negative arm. Two
architectures, one pretext task, one graph, the same outcome -- which points at
the task, not the models. A pretext aligned with what actually predicts fraud
here -- time to the pair's next interaction, given that `row_pair_gap_seconds` is
16.6% of gain -- is the untested alternative.

### The arm that claimed to be 4b was not a TGN row

The old lift table's `+ TGN embeddings` arm (185 features, 0.4768) was **the
R-GCN**.
185 - 57 = 128 = 2 x 64, Stage 2's width; a real TGN arm is 57 + 2 x 100 = 257.
One shared registry did it: `_attach_embeddings` knew a single directory and
Stage 2's `cemb_`/`memb_` prefixes, so the arm named for the TGN was handed the
R-GCN's vectors, and its -0.0496 was the same encoder that lost -0.0231 on the
graph base. Stage 4's export could not have reached the table under any
configuration anyway -- it wrote no `build_id`, which is half the join key.

Four things were needed and are now in place:

1. `temb_c`/`temb_m` in their own registry (`TEMPORAL_EMBEDDING_FEATURES`), so
   the two arms cannot be fed the same tables.
2. A second source directory (`temporal_embeddings_dir`, default
   `artifacts/stage4/embeddings`).
3. `build_id` on the export, from per-build memory snapshots taken as the ordered
   replay crosses each cutoff -- so build `b`'s vectors depend only on events
   below `b`'s cutoff, the same forward-chaining rule the GSQL builds follow.
4. The arm's plan gate keyed on its own family.

The export also used to happen *after* test was scored, so the vectors had
consumed every test event; it now happens before.

An `--objective link` run on 2026-08-04 produced the first genuine 4b tables. The
snapshot boundaries it printed are the forward-chaining property made visible:

```
b_train_f1  cutoff  4,898,618   memory as of <  4,898,618
b_train_f2  cutoff  9,797,235   memory as of <  9,793,338
b_train_f3  cutoff 14,695,853   memory as of < 14,692,154
b_train_f4  cutoff 19,594,470   memory as of < 19,590,970
b_val       cutoff 24,493,087   memory as of < 24,493,087
b_test      cutoff 25,885,128   end of stream
```

Every boundary sits at or below its cutoff, so no build's vectors encode an event
its rows have not yet reached. That ordering is asserted, not assumed, and it is
checked before training starts rather than after -- an earlier run spent 22 epochs
before failing on it.

---

## Why TGN was chosen

The strongest feature in the project is **per-(card, merchant) recency** — which
is precisely what a TGN's memory module computes natively. That is empirical
evidence for the architecture, and it simultaneously diagnoses why Stage 2
failed: static snapshot embeddings from a recency-free objective, handed to a
tree.

Stage 4 is therefore **TGN**, built to do two things off one model:

- **primary** — a supervised fraud head, scoring transactions as they arrive.
  Deliberately breaks D5; must be reported as such.
- **secondary** — memory → embeddings → XGBoost, as
  `raw_plus_temporal_embeddings`, keeping the 2×2 comparable.

---

## Open items

| | |
|---|---|
| Stage 2 has no AUC of its own | can't tell "learned nothing" from "already known" |
| DistMult score as one column | untried, clear mechanism |
| 16 constant community columns | degenerate by design; Louvain measured Q ≈ 0.30/0.04 |
| `cre_max_pair_score` 99.98% null | effectively unused |
| Batch counts are hand-tuned | should derive from a measured census |
| `assert_cardinality` sum exactness | fixed (INT, exact to ~3.0e9) |

## Reproducing

```bash
bash scripts/install_all_gsql.sh                                  # queries
PYTHONPATH=src .venv/bin/python -m tfgnn.tigergraph.temporal      # Stage 3 export
PYTHONPATH=src .venv/bin/python -m tfgnn.tigergraph.assemble      # matrix
make ARGS=--lift-only                                             # arms + charts
```

`--lift-only` reads the matrix and embeddings off disk — no TigerGraph, no GPU.
