# Architecture

How the two in-scope upstream pieces (solution kit + tg-gnn) compose into TF-GNN. Read `docs/REFERENCES.md` first — especially the "Out of scope" section.

Per `docs/DECISIONS_DRAFT.md`, the comparison has **four stages** on one shared TigerGraph + solution-kit feature pipeline; the only variable is what sits on top:

1. **Stage 1 — XGBoost only** (`ml/`). Baseline ↔ NVIDIA's 0.79.
2. **Stage 2 — R-GCN + XGBoost** (`gnn/`). Static GNN embeddings feed XGBoost ↔ NVIDIA's 0.90. R-GCN is the decided model for this stage.
3. **Stage 3 — Temporal + XGBoost, no GNN** (`ml_temporal/`). Time-aware tabular features feed XGBoost; isolates time-awareness without a graph.
4. **Stage 4 — Temporal + GNN + XGBoost** (`gnn_temporal/`). Temporal GNN embeddings feed XGBoost. **Model not final** — GAT / TGN / another temporal model, pending NVIDIA (see `docs/DECISIONS_DRAFT.md` Open item A and `docs/MARKETING_NOTES.md`).

The **no-pollution rule** is non-negotiable: every stage trains/validates/tests on exactly the same rows. Stages 2–4 each begin from a clean training-ready state (decided: Option 1, fresh instance).

## End-to-end flow

```
                  IBM TabFormer dataset or similar (mapped onto the kit schema)
                                   │
                                   ▼
            ┌──────────────────────────────────────────────────┐
            │  TigerGraph — solution-kit schema                │
            │  ─ load via loading_job/load_data.gsql           │
            │  ─ run solution-kit GSQL queries                 │
            │    (co-occurrence edges, PageRank, WCC,          │
            │     shortest path, interval / category stats)    │
            │  ─ add `split` (temporal) on Payment_Transaction │
            └──────────────────────────────────────────────────┘
                                   │
   ┌───────────────┬───────────────┴───────────────┬───────────────┐
   ▼               ▼                               ▼               ▼
Stage 1 (ml/)   Stage 2 (gnn/)            Stage 3 (ml_temporal/)  Stage 4 (gnn_temporal/)
XGBoost only    R-GCN → embeddings        temporal tabular        temporal GNN → embeddings
on kit          → XGBoost                 features → XGBoost      → XGBoost
features        (tg-gnn: cuGraph+PyG)     (no graph)              (tg-gnn, temporal sampler)
   │               │                               │               │
   ▼               ▼                               ▼               ▼
metrics.json    metrics.json              metrics.json            metrics.json
+ model.pkl     + model.pt                + model.pkl             + model.pt
   │               │                               │               │
   └───────────────┴───────────────┬───────────────┴───────────────┘
                                   ▼
                          eval/compare.py
                          → eval/report.{md,html}
                          (AUCPR primary; ROC-AUC, F1, latency, confusion matrix)
```

Everything above is driven by a single `Makefile` at the repo root.

## Schema mapping (TigerGraph → tg-gnn)

The solution kit defines the schema; tg-gnn needs it expressed as a `metadata` dict. Same vertices, same edges, plus a `split` attribute we add.

| Solution-kit vertex   | Role in GNN              | Features (from GSQL queries)                                                          |
|-----------------------|--------------------------|---------------------------------------------------------------------------------------|
| `Cardholder`          | node                     | demographics, in/out degree                                                            |
| `Credit_Card`         | node                     | cd_pagerank, cd_com_size, repeated-card counts                                         |
| `Payment_Transaction` | **label-bearing node**   | max_txn_amt_interval, shortest_path_length, mer_cat_*, `is_fraud` (label), `unix_time` (time_attr), `split` |
| `Merchant`            | node                     | mer_pagerank, mer_com_size                                                             |
| `Merchant_Category`   | node                     | category stats                                                                         |
| `Location`            | node                     | demographics                                                                           |

Edges follow the solution-kit schema (cardholder→card→transaction→merchant→category, plus the co-occurrence edges created in phase 1 of the GSQL pipeline).

`split` is the only attribute we need to write that the kit doesn't already produce — a GSQL query stamps train/val/test on `Payment_Transaction` using `unix_time` for a temporal split.

## Integration seams (where TF-GNN code lives)

1. **`tg/`** — the solution-kit schema, loaders, and GSQL queries, vendored as-is. Add one new GSQL query that writes the temporal `split` attribute on `Payment_Transaction`.
2. **`ml/`** (Stage 1) — thin wrapper around the solution kit's classical ML model in `./model`. Runs on the train rows, evaluates on test rows, writes `ml/metrics.json` + `ml/model.pkl`.
3. **`gnn/`** (Stage 2) — `metadata.py` (the tg-gnn metadata dict for this schema) and `train.py` (the `torchrun` entrypoint that calls tg-gnn export → trains R-GCN → writes `gnn/metrics.json` + `gnn/model.pt`).
4. **`ml_temporal/`** (Stage 3) — time-aware tabular features on `Payment_Transaction` from `unix_time` (no graph) feeding XGBoost; writes `ml_temporal/metrics.json` + model.
5. **`gnn_temporal/`** (Stage 4) — temporal-GNN variant of `gnn/` (model TBD: GAT / TGN / other); writes `gnn_temporal/metrics.json` + `gnn_temporal/model.pt`.
6. **`eval/`** — `compare.py` reads all four `metrics.json` files and emits `eval/report.md` and `eval/report.html` (tables + plots + the §6 comparison caveat).

All four stages reuse a shared metrics module (AUCPR / ROC-AUC / F1 / confusion matrix / latency) so the comparison is honest. That's the whole project. No CDK, no SageMaker, no Triton, no cloud-specific infra.

## Makefile surface (target)

The Makefile is the user surface. Style precedent: AWS sample's Makefile. Our target names reflect *our* stack.

```
make install         # conda env, tg-gnn install, python deps
make tg-up           # start a local TigerGraph (Docker, or a configured remote)
make tg-load         # load solution-kit sample data
make tg-features     # run solution-kit GSQL feature queries + write split
make ml-train          # Stage 1: solution-kit classical ML on TG features
make gnn-train         # Stage 2: torchrun the tg-gnn (R-GCN) training entrypoint
make ml-temporal-train # Stage 3: temporal tabular features → XGBoost (no GNN)
make gnn-temporal-train# Stage 4: temporal GNN → XGBoost
make eval              # produce eval/report.{md,html}
make all               # everything end-to-end
make clean             # tear down
```

`make all` on a fresh clone with a working GPU + CUDA should produce `eval/report.html` with all four stages' numbers.

## Host model

Host-agnostic. The Makefile assumes:

- Local TigerGraph reachable via REST (Docker by default; `TG_HOST` env var overrides).
- NVIDIA GPU(s) with CUDA ≥ 12.8 available wherever `make gnn-train` runs.
- Conda/Miniforge installed (required by tg-gnn).

A laptop with an NVIDIA GPU, an on-prem GPU box, or a cloud GPU VM all work the same way. Cloud deploy is *not* a project requirement — if a workshop needs one, it's an additive layer.

## Serving (open)

After `make all`, the user has the four stages' trained model artifacts (`ml/model.pkl`, `gnn/model.pt`, `ml_temporal/model.pkl`, `gnn_temporal/model.pt`) and a benchmark. Whether we add a serving layer (small REST app, gRPC, etc.) is open. Pick once training is working end-to-end.
