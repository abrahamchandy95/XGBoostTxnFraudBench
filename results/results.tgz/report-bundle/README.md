# TF_GNN — does a graph help detect payment fraud?

A four-stage controlled comparison on one TigerGraph instance. The variable is
what sits on top of the graph; everything below it is held byte-identical.

**The question is not "can we detect fraud."** It is *"which parts of a graph
stack actually earn their place, and by how much, with intervals."* Most work in
this space reports a GNN number with no comparable baseline. This reports six
arms on identical rows with a paired bootstrap on every difference — including
the arms that lost.

---

## 1. What we set out to build

`docs/DECISIONS_DRAFT.md` specifies a 2×2 over `{no-GNN, GNN} × {no-temporal,
temporal}`, all four cells on the same TigerGraph schema and the same GSQL
feature queries:

| | no temporal | temporal |
|---|---|---|
| **no GNN** | Stage 1 — XGBoost baseline | Stage 3 — temporal features |
| **GNN** | Stage 2 — R-GCN embeddings | Stage 4 — temporal GNN |

Under one non-negotiable constraint, quoted from the design doc:

> **NO POLLUTION RULE.** Every stage must train on exactly the same train rows,
> validate on exactly the same val rows, and test on exactly the same test rows.
> Not a single transaction can differ across the four stages.

That rule is why this is a comparison rather than four experiments.

---

## 2. The data

| | |
|---|---|
| transactions loaded | **27,404,317** |
| assembled into the matrix | 22,505,700 |
| withheld as warm-up | 4,898,617 |
| cards / merchants | 68,618 / 1,027 |
| train / val / test | 19,594,469 / 1,392,041 / 1,519,190 |
| fraud prevalence | 0.1402% / 0.1560% / **0.1293%** |

**Test is 36.4% inductive** — that share of test rows carry a card or merchant
the training set never saw. Every result below should be read against that.

**The corpus and the graph are fixed.** One dataset, one schema, one load —
every arm in every table above is measured on exactly these rows, which is what
makes the paired bootstrap a comparison rather than four experiments. The counts
are still read from `assert_cardinality` and `assert_edge_stamp` at run time
rather than from prose, because a gate that recounts is what proves the constant
held.

---

## 3. System design

```
Postgres  ──►  TigerGraph 
                            │
                    ┌───────┴────────────────────────────────┐
                    │  STAGE 1 FEATURE BUILD — all in GSQL   │
                    │  6 forward-chaining snapshots          │
                    │                                        │
                    │  0  assert_cardinality                 │  load gates
                    │     assert_edge_stamp                  │
                    │     derive_build_plan                  │
                    │  1  reset_build (batched)              │
                    │  2  entity resolution (8 queries)      │
                    │  3  build_interaction_edges            │  the cutoff guard
                    │     verify_interaction_build           │
                    │     card_merchant_degree_stats         │  sets `seen`
                    │     card_home_distance                 │
                    │  4  wcc / pagerank (bipartite)         │
                    │  5  aggregates, community stats        │
                    │  6  export dimensions per build        │
                    └───────┬────────────────────────────────┘
                            │
    ┌───────────────────────┼───────────────────────┬──────────────────┐
    ▼                       ▼                       ▼                  ▼
export_transaction_rows  card_row_temporal   export_graph_edges   tgn_window_neighbors
  (fact table)           (Stage 3, once)       (Stage 2)         (NOT used, future scope)
    │                       │                       │                  ┆
    └───────────┬───────────┘                       ▼                  ┆
                ▼                              R-GCN (PyG)             ┆
         assemble → matrix ──► TGN (PyG) ◄╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌┘
                │                  │                │
                │            temb_ embeddings  cemb_/memb_ embeddings
                │                  │                │
                └──────────► XGBoost, 8 arms ◄──────┘
                                   │
                              paired bootstrap → report.png
```

### The star schema, and why

Schema r3 states `NO BUILD QUERY WRITES Payment_Transaction. It is read-only
after load.` So graph features live on `Card`, `Merchant`, `Merchant_Category`,
`Community` and `Resolved_Entity`, and reach a transaction through a key it
carries. The export is therefore **one fact table plus five dimension tables
plus one pair table**, and `assemble` performs the join.

`src/tfgnn/features_meta.py` is the single place both sides of that join are
named. A column-count drift shows up there as a name mismatch rather than a
silent reindex.

### Forward chaining, not one snapshot

Six builds, each fitted strictly below its own `cutoff_event_seq`, each serving
only rows at or after it:

```
b_train_f1  cutoff  4,898,618   serves split 0
b_train_f2  cutoff  9,797,235   serves split 0
b_train_f3  cutoff 14,695,853   serves split 0
b_train_f4  cutoff 19,594,470   serves split 0
b_val       cutoff 24,493,087   serves split 1
b_test      cutoff 25,885,128   serves split 2
```

No training row reads a feature fitted over a window containing itself. Rows
below the first boundary are warm-up: they contribute topology and are never
scored.

---

## 4. Engineering choices, and why

### Everything graph-shaped stays in GSQL

PageRank, WCC, entity resolution, community statistics, the aggregates and the
temporal features are all computed **inside TigerGraph**. Nothing is downloaded
to be computed client-side. This was tested once — a client-side numpy PageRank
was proposed and rejected outright — and the constraint held for the rest of the
project. It is what makes the comparison a statement about TigerGraph rather
than about pandas.

### Bipartite-native, not materialised projections

Graph features derive from `Has_Interaction_With_Merchant` — the *cutoff guard*.
`Card_Card` and `Merchant_Merchant` projections derive entirely from it, so
filtering once there makes both cutoff-correct by construction. The materialised
projections were retired: one merchant reaches ~51% of all cards, and
Σ over merchants of degree² is infeasible at that skew.

### The cutoff is evaluated on the hop-1 EDGE

Three queries used to filter on the hop-1 *destination* (`t.event_seq < cutoff`),
forcing a `Payment_Transaction` dereference before a row could be rejected —
so every build paid for the whole corpus however early its cutoff was. They now
read `e.edge_event_seq`, decidable while walking the adjacency.

That substitution is legitimate only if `edge_event_seq == t.event_seq`, and
**two already-wired gates enforce it** rather than a feature flag: the load gate
`assert_edge_stamp` sits at flat index 1 ahead of every build, and
`verify_interaction_build` recounts from the vertex side per build. Writer on the
edge, verifier on the vertex.

### Per-invocation batching, because inserts commit at query end

`reset_build`, `build_interaction_edges`, `card_home_distance` and the
projection builders partition by `getvid % num_of_source_batches`, **one batch
per call**. Looping inside one query bounds accumulators but not the
transaction, and this is the query whose write set grows with every fold.

A production run aborted with `System Memory in Critical state` at
`interaction_batches: 10`; the per-batch timings were 9.9 s, 141.0 s, abort — a
14× spread across a supposedly even split, which is partition skew, not compute.
`getvid` is segment-based and sparse, and 10 = 2·5 shares a factor with every
power-of-two stride. Now **41**: prime, odd, coprime to any such stride.

### Gates are enforced by output-key naming

Any query printing `*_MUST_BE_ZERO`, `ABORT_*` or `*_MUST_EQUAL_*` is checked by
`gates.py` with **no per-call wiring**. Adding a gate means naming a print key.

That convention is why the hop-1 rewrite needed no plumbing, and why every
correctness claim in the pipeline is machine-checked rather than commented.

### Two offline checks that run before TigerGraph is touched

- `scripts/validate_stage1_static.py` — 57 scripts, 59 queries: accumulator
  declarations, attribute resolution against the 90-name schema set, reserved
  words, parameter agreement with the pipeline, install coverage, orphan
  queries, and the column contract.
- `scripts/smoke_stage1_offline.py` — a synthetic `FakeGraph` answering
  TigerGraph-shaped payloads, exercising 38 queries end to end through export,
  assembly, sentinel conversion and the four arms that need no embeddings. All
  five embedding arms skip with a `NOTE`: the smoke points `embeddings_dir` and
  `temporal_embeddings_dir` at an empty workspace on purpose, so a real
  embedding table is never joined onto a synthetic matrix.

Both must pass before a run. They exist because a 40-minute build is the wrong
place to discover a renamed print key.

### Inductive, not transductive — and it is not ARCHITECTURE.md that says so

**Where the decision lives.** Not in `docs/ARCHITECTURE.md`, which never uses
either word. It is `docs/DECISIONS_LEAK_CONTROL.md` **D3d**, written after the
plan and superseding part of it. `ARCHITECTURE.md` specifies the pipeline shape;
this is one of the things it left unstated.

**And the transductive reference is AWS, not NVIDIA.** D3d is specific:

> *"The widely-cited **AWS** reference implementation in this space is explicit
> that its R-GCN is trained and tested transductively, with a learned embedding
> for each featureless node such as IP address."*

Nothing in this repository attributes a transductive setting to NVIDIA. The
NVIDIA blogs are the source of the *methodology* mirrored here — GNN embeddings
feeding XGBoost — and of the 0.79 / 0.90 figures that are **not** our reference
numbers because they were measured on TabFormer.

**What the two settings mean.** Transductive evaluation makes the whole graph —
including every test node and its incident edges — available during training, so
gradients flow along paths connecting unlabelled test nodes to labelled training
ones. Inductive evaluation withholds test-period structure, and per D3d is *"the
setting a deployed fraud detector actually faces."*

**Why we went inductive.** Two mechanical reasons, both from D3d, and neither is
about elegance:

1. **A learnable per-node ID embedding is a lookup table.** A test-period card
   absent from training has **no embedding at all** — not a poor one, none. The
   model cannot score it.
2. **The model is otherwise free to memorise node identity** rather than learn a
   function of features and neighbourhood.

**How it is enforced, in two places.** No learnable per-node ID embeddings: node
inputs are the Stage 1 aggregate block — shared byte for byte with the XGBoost
arms — plus a ones-vector fallback for entities with no history
(`src/tfgnn/stage2/schema_spec.py`). And at the export, per D3d: *"a training-fold
export contains only topology below that fold's cutoff, so it is inductive by
construction… Residency in the database is fine; the **export** is where
inductivity is reconstructed."* The control table carries
`is_inductive_export` and `learnable_id_embeddings_used`, the latter required to
be FALSE.

**What it buys.**

- **Cold start.** A card first seen in production is scored by the same function
  as one seen for years. That is the deployment case, not an edge case.
- **No identity shortcut.** The model cannot reach a good training loss by
  memorising which nodes are which.
- **One less leak channel.** Transductive training lets gradient signal travel
  from labelled training nodes to unlabelled test nodes through shared structure;
  withholding test-period topology closes that path.
- **It is what makes Stage 4a coherent.** An at-arrival scorer reads memory that
  is a function of *events*, not of an identity looked up in a table — so the
  same model scores a brand-new card on its first transaction.

**What it costs:** the architectures it rules out. D3d says so directly — *"it
eliminates some architectures outright"* — including the AWS-style R-GCN with
per-node embeddings for featureless vertices.

**Measured, and it is a result rather than a property.** `manifest.json`'s
`inductive_reach`, read on 2026-08-04:

| test | count | share |
|---|---|---|
| cards the training set never saw | **5,287 of 12,868** | 41.1% of test cards |
| merchants never seen | 50 of 462 | 10.8% of test merchants |
| **test rows carrying either** | **552,579 of 1,519,190** | **36.4%** |
| — via an unseen card | | 35.6% |
| — via an unseen merchant | | 1.2% |

Validation for contrast: 11.8% of rows, 20.8% of its cards. Training saw 63,061
cards and 975 merchants.

**So every number in §6 is measured WITH those 552,579 cold-start rows in it.**
0.5631 AUC-PR and 436× base rate are not a score on the easy subset — 36.4% of the
test set involves an entity the model had never trained on, and D3d's no-ID-embedding
rule is what makes those rows scoreable at all. `docs/STAGE1_RUNBOOK.md` carries a
caveat stamped to the **2026-07-30** load saying the reach was zero; that load is
superseded and the caveat no longer applies to this matrix.

### Sentinels: −1 means "not computed", never 0

Every build-scoped numeric defaults to −1 and reaches XGBoost as **NaN**. Zero
would make "unseen" a value, and unseen correlates with "appears later in time",
so the model would learn a calendar proxy.

Two conversion rules, because they are not equally safe. Counts and degrees are
tested against −1 directly. **Amounts are not** — a total of −1.0 is legal for a
refund — so each amount block is guarded by the count written in the same
`IF count > 0` branch.

---

## 5. What each GNN learns, and what each arm sees

### Are the GNNs just bolted onto XGBoost at the end?

For two of the three, **yes — and that is the design, not an accident.** It is the
contract this project set out to test, mirroring the published NVIDIA recipe: train
a GNN, read out a vector per node, append it as columns, let the tree decide. The
third is different.

| | Stage 2 — R-GCN | Stage 4a — TGN | Stage 4b — TGN |
|---|---|---|---|
| architecture | static heterogeneous GNN | temporal GNN + supervised head | *the same TGN*, self-supervised head |
| trained on | link prediction, **no label** | **the fraud label** — breaks D5 | link prediction, **no label** |
| what is used | 128 node vectors | a fraud score per transaction | 200 node vectors |
| reaches XGBoost? | yes, as 128 columns | **no — never enters the lift table** | yes, as 200 columns |
| the question it answers | does *learned* structure add to *engineered* structure? | can a GNN catch fraud **as it arrives**? | does learned *temporal* structure add? |

4a is the only one that is a predictor rather than a feature generator. It reads
memory and outputs a probability, so there is no tree downstream — and because it
trains on the label it is reported alone and never inside the lift table.

### What the R-GCN's 64 numbers per node contain

**Its input is the Stage 1 aggregate block** — the card's own `txn_count`,
`total_amount`, `avg/min/max_txn_amount` — shared byte for byte with the XGBoost
arms. Plus a ones-vector for entities with no history. Explicitly **no learnable
per-node ID embedding**, because D3d requires the model to be inductive.

Message passing runs over **nine relations with separate weights per relation**
(`Party_Has_Card`, `Party_Shares_Device`, `Party_Shares_IP`, `Merchant_Assigned`,
the transaction relations). That is what R-GCN is for, and it is genuinely used.
`Card_Card` is deliberately excluded — it reconstructs the target.

So the 64 numbers are: *a compressed summary of my aggregates, plus the aggregates
of everything I am connected to — my Party, that Party's shared-device partners,
their cards, my merchants, their categories — weighted by whatever predicts my
merchant edges.*

### What the TGN's 100 numbers per node contain

**Its input is 27 feature columns per event** — `amount`, `is_online`, the graph
block, and **Stage 3's nine temporal columns** — plus 27 missingness flags. A GRU
consumes 354 numbers on every transaction a node touches (54 raw + 100 source
memory + 100 destination memory + 100 time encoding) and folds them into a 100-dim
state.

So the 100 numbers are: *a running compressed summary of what my recent
transactions looked like*, in the vocabulary of those 27 features.

> **R-GCN = where you sit in the graph, described by your neighbours' aggregates.**
> **TGN = what you have been doing lately, described by your own event features.**

### Why both lose — one mechanism, not two

Each is a **learned, lossy approximation of something the star-schema join already
delivers exactly.**

| the network learns, approximately | the join already provides, exactly |
|---|---|
| R-GCN: neighbours' aggregates, mixed over the graph | `mer_*`, `cat_*`, `ccom_*`, `mcom_*`, `cre_*` — the merchant's, category's, community's and resolved entity's aggregates, on every row |
| TGN: recent behavioural history | the nine `row_*` temporal columns — which are literally its own input |

The R-GCN's inputs are the aggregate features and XGBoost has those directly. The
TGN's inputs are the temporal features and XGBoost has those directly. Each
compresses into 128 or 200 dense columns what the join hands over losslessly — and
then a tree, which splits one dimension at a time, works from the compression
instead of the original.

That single mechanism explains the R-GCN's −0.0231 and the near-chance link
pretext without either model being broken. It is also why the **pair-score arms**
exist: three columns (dot, cosine, L2) keep whatever the encoder knows about a
*pair* in a form a tree can actually split on.

### What each arm sees

`contract` is what `variant_columns` names. `+derived` adds the 19 columns
`build_features` computes for every arm — `amount`, `is_online`, four time
components, eleven one-hot columns, two forward-chaining target encodings.
`-dropped` is the train-fitted removal of all-NaN and constant columns.

| arm | contract | +derived | −dropped | **model sees** |
|---|---|---|---|---|
| raw | 4 | 19 | 0 | **19** |
| + aggregates | 22 | 37 | 2 | **35** |
| + graph | 59 | 74 | 23 | **51** |
| + temporal | 68 | 83 | 23 | **60** |
| + R-GCN embeddings | 187 | 202 | 23 | **179** |
| + TGN embeddings | 268 | 283 | 23 | **260** |
| R-GCN instead of graph | 150 | 165 | 2 | **163** |
| + R-GCN pair score | 62 | 77 | 23 | **54** |
| + TGN pair score | 71 | 86 | 23 | **63** |

The blocks those counts are built from: **4** fact attributes (`amount`,
`use_chip`, `error`, `is_online`), **18** aggregates, **37** graph, **9**
temporal, **128** R-GCN dimensions, **200** TGN dimensions, **3** pair scores.

**Every arm is a strict superset of a shallower one**, which is what makes a lift
attributable. Two consequences that are easy to get wrong:

- `+ R-GCN embeddings` **contains** the graph block, so its baseline must be
  `+ graph`, not `raw`. Compared against raw it scores 0.1919 versus 0.1711 and
  looks like a win; compared against the arm holding everything except its 128
  columns it costs **0.0231**, which is 53% of the +0.0439 that the aggregates and
  graph features had earned.
- `+ temporal` and `+ R-GCN embeddings` are **siblings** off `+ graph` — the two
  cells of the 2×2 — so their lifts are directly comparable. `+ TGN embeddings`
  and `+ TGN pair score` are siblings off `+ temporal` for the same reason.

**23 columns are dropped from every graph-carrying arm**: 7 all-NaN because
`louvain`, `kcore` and `card_interval_max` are `false` in `config.yaml`, and 16
constant because WCC collapses into one giant component. So the +0.0099 graph lift
was earned with **51 effective features and no community signal at all**.

---

## 6. Results

Test fraud prevalence is **0.1293%**, so random guessing scores 0.00129 AUC-PR.
Every number below should be read against that, not against 1.0.

| arm | features | test AUC-PR | 95% interval | vs random | test ROC-AUC |
|---|---|---|---|---|---|
| raw | 19 | 0.1711 | [0.1560, 0.1886] | 132× | 0.9053 |
| + aggregates | 35 | 0.2051 | [0.1868, 0.2235] | 159× | 0.9219 |
| + graph | 51 | 0.2150 | [0.1961, 0.2320] | 166× | 0.9441 |
| **+ temporal** | **60** | **0.5631** | **[0.5412, 0.5840]** | **436×** | **0.9909** |
| + R-GCN embeddings | 179 | 0.1919 | [0.1756, 0.2094] | 149× | 0.9425 |
| R-GCN instead of graph | 163 | 0.1924 | [0.1768, 0.2149] | 149× | 0.9161 |
| + R-GCN pair score | 54 | 0.2161 | [0.1981, 0.2355] | 167× | 0.9486 |
| **+ TGN pair score** | **63** | **0.5635** | **[0.5423, 0.5888]** | **436×** | **0.9908** |
| + TGN embeddings | 260 | *not measured* | — | — | — |

| lift | value | 95% interval | P(better) | verdict |
|---|---|---|---|---|
| raw → aggregates | +0.0341 | [+0.0232, +0.0452] | 1.000 | significant |
| aggregates → graph | +0.0098 | [+0.0025, +0.0171] | 1.000 | significant, thin |
| graph → **temporal** | **+0.3482** | [+0.3253, +0.3698] | 1.000 | **the project's result** |
| graph → R-GCN embeddings | **−0.0231** | [−0.0325, −0.0129] | 0.000 | **worse** |
| graph → R-GCN *instead of* graph | **−0.0226** | [−0.0327, −0.0116] | 0.000 | **worse** |
| graph → R-GCN pair score | +0.0011 | [−0.0063, +0.0079] | 0.630 | **zero** |
| R-GCN embeddings → R-GCN pair score | **+0.0242** | [+0.0171, +0.0317] | 1.000 | **significant** |
| temporal → TGN pair score | +0.0003 | [−0.0077, +0.0078] | 0.460 | **zero** |

Every interval is a paired percentile bootstrap on the *difference*: both arms are
resampled with the same row weights on each draw, so two overlapping single-arm
intervals are still compatible with a difference that is positive on every
resample. `P(better)` is the share of resamples in which the candidate wins.

### The GNN result, in three lifts

The last three rows are the point of the 2026-08-04 run, and together they say
something more precise than "the GNN did not help."

**Presenting 128 raw dimensions to a tree is actively harmful.** Same encoder,
same base, only the presentation changed — three pair statistics (dot, cosine, L2)
instead of 128 dimensions — and the pair form wins by **+0.0242**, interval clear
of zero, P(better) = 1.000. The −0.0231 was **dilution**, not the encoder being
uninformative. A tree splits one dimension at a time and cannot form the dot
product a link-prediction decoder was trained to produce.

**But the R-GCN's information content, once the dilution is removed, is zero.**
`graph → R-GCN pair score` is **+0.0011 [−0.0063, +0.0079]**, P(better) = 0.630 —
indistinguishable from noise. Not negative. Not positive. Nothing. The encoder
knows nothing about fraud that PageRank, entity resolution and pair geography do
not already say.

**And the same for the TGN.** `temporal → TGN pair score` is **+0.0003 [−0.0077,
+0.0078]**, P(better) = 0.460. Stage 4b's question is therefore **answered**
without the 260-column arm: the TGN read-out adds nothing to the temporal features
it was itself fed. Which is exactly what the redundancy argument in §5 predicts —
its message vector *is* those columns.

**A fourth reading, from the arms rather than the lifts.** `+ R-GCN embeddings`
scores 0.1919 and `R-GCN instead of graph` scores 0.1924 — statistically the same.
So *adding the whole hand-built graph block on top of the embeddings buys nothing*.
128 dense columns do not merely fail to add; they crowd out features that were
worth +0.0098 on their own. The dilution is visible twice, from two directions.


**The `+ TGN embeddings` row is unmeasured, and the number that used to sit there
was not a TGN result.** It read 185 features and 0.4768. The arithmetic gives it away:
185 − 57 = 128 = 2 × 64, which is Stage 2's R-GCN width, where a real TGN arm is
57 + 2 × 100 = 257. The cause was a single shared registry — `_attach_embeddings`
knew one directory and Stage 2's `cemb_`/`memb_` prefixes, so the arm named for
the TGN was fed the R-GCN's vectors and its −0.0496 was *the R-GCN losing on the
temporal base*, the same encoder that lost −0.0231 on the graph base. Stage 4's
export could not have reached the table under any configuration: it wrote no
`build_id`, which is half the join key. Both are fixed (`temb_c`/`temb_m` in
their own registry, per-build snapshots), and the arm now carries a genuine TGN
read-out from an `--objective link` run.

**And its question is already answered by the pair-score arm.** `+ TGN pair score`
carries the same encoder in three columns and lands at +0.0003 [−0.0077, +0.0078] —
zero. The 260-column version would test presentation, not information, and the
information is what was in doubt.

Stage 4a (supervised TGN, scores transactions directly, **breaks D5**):
**0.3241** AUC-PR, ROC-AUC 0.9805, **251× base rate**. Graph attention on, 10
neighbours, 27 kept message columns (raw_dim 54), seed 13, best epoch 14 of 19
run at patience 5, ~6.2 min/epoch. Two caveats travel with that number:

- It is **not an architecture comparison**. The TGN sees 27 columns; the 0.5631
  arm sees 60, including the 18 aggregates and the calendar/target-encoding
  block that the message vector deliberately excludes. Read 0.3241 vs 0.5631 as
  two feature sets, not two models.
- **Val is measured in a different regime from test**, by about 0.046 AUC-PR.
  PyG's `TGNMemory.forward` returns `_get_updated_memory()` in train mode and the
  committed table in eval mode, so a train-mode pass and an eval-mode pass over
  the same stream leave memory in different states. Early stopping selects on the
  train-mode number while the reported test score is eval-mode — which is the
  deployment-faithful one. Both are leak-free; they are not the same measurement.
  Measured on the link run: best epoch 10 reported val 0.6109, and the same
  weights replayed in eval mode gave 0.5650.

**Superseded 4a numbers**, recorded because the trajectory is the argument:
0.3964 (memory-only, `--no-attention`, 11 message columns — uses no graph);
0.1888 (48 message columns of which 21 were dead); 0.3824 (attention on, but its
edge time feature was **constant** — `t - last_update` was written backwards so
`clamp(min=0)` zeroed every edge, measured 0 of 20,507 carrying a non-zero value,
and test was scored with memory that had skipped the whole val split). None of
those are comparable to each other or to 0.3241: the scoring regime moved, and
Stage 4 was unseeded until 2026-08-03.

### What that says

**Graph features help, modestly.** +0.0098 over the cheap aggregates, interval
clear of zero but with a lower bound of +0.0025. Earned with **23 of 74 columns dead** — 7 all-NaN (disabled optional families) and 16 constant, because WCC
collapses into one giant component that a hub merchant welds together. The lift
comes from entity resolution and pair geography, not centrality or community.

**Per-row temporal features dominate.** **+0.3482 from nine features**, and that is
the largest effect in the project by a factor of thirty-five over the graph block.
The driver is
`row_pair_gap_seconds` at 16.6% of gain — *"this card has never used this
merchant before"* — measured on test at **11.3× enrichment**:

```
first-visit share        7.97%
P(fraud | first visit)   0.801%
P(fraud | repeat)        0.071%
```

Half the test fraud sits in 8% of the rows, and 99.2% of first visits are
legitimate — so it is a calibrated signal, not the generator handing over the
label.

**Graph-neural embeddings hurt as presented, and carry nothing once they aren't.**
The R-GCN arm scores 0.1919, *above* raw's 0.1711 — so read carelessly it looks
like a win. It isn't: the arm is a **strict superset** of `+ graph` (187 columns =
the same 59 plus 128 embedding dims), so comparing it to raw credits the GNN with
the +0.0341 the aggregates earned and the +0.0098 the graph features earned. Against
the arm holding everything except those 128 columns it costs **0.0231** — 53% of the
+0.0439 the feature engineering had earned.

And the three-lift reading above says why: **+0.0242 of that was dilution** (the
pair form recovers it) and **the remaining information content is zero** (+0.0011,
interval spanning zero). The mechanism is visible in the importances too —
`best_iteration` collapsed to 53 while the temporal arm reached 148, and only one
embedding (`cemb_13`, 2.1%) makes the top eight, below the hand-built
`card_pagerank` (5.6%) and `mer_pagerank` (5.5%).

**The GNN cannot replace the hand-built graph features either.** That comparison
did not exist until 2026-08-04 — every embedding arm carried the graph block
*alongside* the embeddings, so nothing tested substitution. `R-GCN instead of graph`
drops PageRank, entity resolution and pair geography and keeps the 128 dimensions:
**−0.0226 [−0.0327, −0.0116]**, P(better) = 0.000. Engineered structure beats
learned structure on this graph, significantly.


---

## 7. What the GNN offers that the trees do not

The accuracy table undersells it, because it has only one axis:

| | test AUC-PR | training footprint | new accounts |
|---|---|---|---|
| XGBoost + temporal | **0.5631** | O(rows) — whole matrix resident | features are NaN |
| TGN (4a) | 0.3241 | **O(batch)** — one batch at a time | **real state after one event** |

Trees compute global split statistics over all rows, so there is no incremental
version: you retrain from scratch or not at all. TGN's memory *is* state, so it
extends as transactions arrive — which is the only route to continuous training,
and the reason 36.4% inductive test rows are handled natively rather than as
missing data.

**The honest framing is a trade, not an improvement.** At 0.24 AUC-PR below the
trees — on a narrower feature set — the TGN trains in O(batch), handles
never-seen accounts, and can be driven incrementally. Whether that is worth it
depends on whether you have 22M rows or 22B.

---

## 8. Limitations, stated plainly

**Synthetic data.** Magnitudes reflect the generator. The *ordering* of the six
arms transfers; 0.5631 does not.

**The inductive setting is exercised, and that is worth stating precisely.** 36.4%
of test rows carry a card or merchant absent from training (41.1% of test cards),
so cold-start generalisation is demonstrated rather than merely permitted by the
architecture. What is *not* demonstrated is that it holds under real entity churn:
this is one synthetic load, and a bank's churn profile differs.

**Deep and narrow; a bank is shallow and wide.** 8,000 parties over 20 years,
against 50M customers over 18 months of retention. `row_card_tenure_seconds`
spans two decades here and would be near-useless under a short retention policy.

**No production path.** `label_available_unix_time` is declared and **dormant** —
a bank learns of fraud weeks later via chargeback, so continuous training on
labels as they appear would leak. There is no single-event inference path, and
the memory table would need checkpointing and exactly-once updates.

**cuGraph: installed and detected, NOT yet used.** This entry has been wrong
twice and the current state is worth stating precisely.

`pip install cugraph-cu12 cugraph-pyg-cu12 cudf-cu12` emits a dependency
conflict against torch 2.13.0+cu132 — it downgrades the pip-declared
`cuda-toolkit` from 13.2.1 to 12.9.2 while torch declares 13.2.1 as a hard
requirement. **That warning is not a runtime failure.** Empirically both coexist:
`cugraph_sampler.describe()` reports `GPU sampling ENABLED`,
`torch.cuda.is_available()` returns True, and a full 10-epoch Stage 4 run
completed on CUDA at 69 ms/step afterwards. torch links its own CUDA runtime and
its pip metadata is stricter than what it actually needs.

The real gap is not the install. **`src/tfgnn/stage4/cugraph_sampler.py` only
PROBES.** `describe()` and `available()` are called; `build_store()` is not. The
neighbour sampling still runs through PyG's `LastNeighborLoader`, so
`"cugraph": true` in `stage4_metrics_*.json` means *available*, not *used*.

Wiring it means replacing that loader with a `cugraph_pyg` GraphStore over each
window's edges. Expected effect: **throughput only.** Same last-N semantics, same
edges, same attention — if accuracy moves, that is a bug to chase rather than a
win. And at this graph size there may be nothing to gain: median step time was
69 ms both with cuGraph absent and with it installed-but-unused, so the sampler
is not currently the bottleneck. That measurement should come before the wiring,
not after.

**D5 is broken for Stage 4a, deliberately.** The supervised head trains on the
fraud label. `stage4_metrics_fraud.json` records `breaks_d5: true` and the reason.
It is never reported inside the XGBoost lift table, because an arm trained on the
label is not comparable to arms that were not.

**Stage 4b is compliant only under `--objective link`, which is not the default.**
The read-out itself never sees a label, and for a while that was the whole check —
but under `--objective fraud` the *memory being read* was shaped by BCE gradients
on `is_fraud`, so the vectors are label-shaped even though the export is not. A
fraud run writes to `embeddings_fraud/`, which the lift table does not read; only
a link run writes the directory it does.

**The link pretext task is close to vacuous on this graph, and that is a finding
about the data.** The self-supervised run scored **0.5624 test AUC-PR / 0.5684
ROC-AUC on a balanced target** — chance is 0.5 — and its training loss reached
0.6688 against `-ln(0.5) = 0.6931`, i.e. **3.6% of the way** from knowing nothing.
The reason is density: a card touches roughly **281 of 1,027 merchants**, so the
bipartite graph is about **27% dense**, where Cora is 0.074% and ogbl-collab
0.0023%. When a quarter of all possible edges exist, "does this edge exist?"
carries almost no information — and uniform in-batch negatives are then ~27% false
negatives, capping even a perfect model near ROC-AUC 0.863.

That matters beyond Stage 4, because **link prediction is the D5-compliant pretext
task in both GNN stages.** The R-GCN used it too and also produced a negative arm.
Two architectures, one pretext task, one graph, same outcome — which points at the
task rather than the models.

**No comparison to published benchmarks.** NVIDIA's 0.79/0.90 are on TabFormer;
this is not TabFormer, and 0.5631 is below them regardless. The claim worth
making is methodological, not a leaderboard position.

---

## 9. Running it

```bash
make            # everything, end to end
make check      # validate and print the plan; writes no data
make report     # redraw charts from artifacts on disk
```

Narrower runs use `ARGS=`, not more targets:

```bash
make ARGS=--no-gnn        # stop after the XGBoost arms
make ARGS=--gnn-only      # reuse the feature build, skip to the GNN
make ARGS=--lift-only     # all arms + charts, from disk only. No TigerGraph.
make ARGS=--from-export   # reuse the feature build AND the fact export
```

Individual steps need `PYTHONPATH=src` — nothing pip-installs this project:

```bash
bash scripts/install_all_gsql.sh                                   # CREATE + INSTALL
PYTHONPATH=src .venv/bin/python -m tfgnn.tigergraph.preflight       # auth + schema
PYTHONPATH=src .venv/bin/python -m tfgnn.tigergraph.pipeline        # feature build
PYTHONPATH=src .venv/bin/python -m tfgnn.tigergraph.export          # fact table
PYTHONPATH=src .venv/bin/python -m tfgnn.tigergraph.temporal        # Stage 3
PYTHONPATH=src .venv/bin/python -m tfgnn.tigergraph.assemble        # the matrix
PYTHONPATH=src .venv/bin/python -m tfgnn.stage4.run                 # Stage 4a
PYTHONPATH=src .venv/bin/python -m tfgnn.stage4.run --objective link  # Stage 4b
```

The feature build is resumable: `pipeline --from-index N` picks up where a failed
run stopped. Changing a batch count invalidates that — residues repartition — and
the guard refuses the resume rather than leaving vertices in no batch.

### Two machines

The GNN is GPU-resident; the feature build needs only TigerGraph, pandas and
XGBoost. Move the megabytes, not the gigabytes:

```
CPU box   make ARGS=--no-gnn
          copy data/stage1/export/dimensions/  → GPU box    (small)
GPU box   make ARGS=--gnn-only
          copy artifacts/stage2/embeddings/    → CPU box    (~4 MB)
CPU box   make ARGS=--lift-only
```

---

## 10. Where to read further

| | |
|---|---|
| `SUMMARY.md` | measured results, all stages, with the leak audit |
| `systemprompt.md` | working state and hard-won facts; every reversal recorded |
| **`docs/PLAN_VS_BUILT.md`** | **every design commitment vs what shipped, and why it moved** |
| `docs/DECISIONS_DRAFT.md` | the original four-stage specification — **preserved unedited** |
| `docs/ARCHITECTURE.md` | the original intended module layout — **preserved unedited** |
| `docs/DECISIONS_LEAK_CONTROL.md` | D3a, D3c, D5, D6 — the leak rules |
| `gsql/*/[query].gsql` | every query carries its own reasoning in the header |

The GSQL headers are the primary documentation. They record what was tried, what
failed, and why the current form is what it is — including the measurements that
settled each argument.
