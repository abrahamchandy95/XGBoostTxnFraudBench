# Report brief — instructions for writing up this project's results

**Audience for the report: the engineering team.** Not marketing, not an exec
summary. They will ask what was measured, how, and what it means for what they
build next.

**This file ships inside the report bundle.** It is written for whoever — person
or model — is handed the bundle and asked to produce the write-up. Read it before
the artifacts.

---

## 1. The one-sentence result, with its sign

> On this corpus, hand-built GSQL **temporal** features are worth **+0.3482
> AUC-PR** (436× the base rate). Both GNNs are worth **zero** — +0.0011 for the
> R-GCN, +0.0003 for the TGN, both intervals straddling zero — and the R-GCN's
> 128-column form is worth **−0.0231**, actively worse than not having it.

**That is the opposite sign from what the project was designed to show.** Do not
soften it, and do not bury it. The design (§4 below) was built to mirror NVIDIA's
published 0.79 → 0.90 XGBoost → GNN+XGBoost improvement. The measurement says
that on this data the graph pays through **hand-specified features** and not
through learned embeddings. An honest negative with an interval is the
deliverable; a hedged positive is not.

---

## 2. The artifacts, by name

Every number in the report must be traceable to one of these.

### Results — read these first

| file | what it holds |
|---|---|
| `stage1_comparison.json` | **The primary artifact.** Per-arm results and every lift. See §3. |
| `metrics_raw.json` | per-arm detail: 19 features |
| `metrics_raw_plus_aggregates.json` | 35 features |
| `metrics_raw_plus_graph.json` | 51 features |
| `metrics_raw_plus_temporal.json` | 60 features — the winning arm |
| `metrics_raw_plus_embeddings.json` | 179 features — R-GCN, wide form |
| `metrics_raw_plus_aggregates_embeddings.json` | 163 features — R-GCN *replacing* the graph block |
| `metrics_raw_plus_pair_scores.json` | 54 features — R-GCN as 3 pair statistics |
| `metrics_raw_plus_temporal_pair_scores.json` | 63 features — TGN as 3 pair statistics |
| `stage2_metrics.json` | R-GCN training: per-epoch train + held-out val loss, negative-sampling regime, temporal guarantee |
| `stage4_metrics_link.json` | TGN under the **link** objective (D5-compliant). Scores, per-epoch history, `seed`, `memory_dim`, `neighbours`, `raw_dim` |
| `stage4_metrics_fraud.json` | TGN under the **fraud** objective. **Not comparable to the arms** — see §5.3 |
| `run.log` | **Required, not optional.** See §2.1 |
| `report.png` | The four-panel figure. Every number in it is also in the JSON; prefer the JSON |

### 2.1 Why `run.log` is required

The **top-features-by-gain table is printed to stdout and written to no JSON
file.** It exists nowhere else. Without the log the report cannot say *which*
feature produced the 436×, which is the first question any engineer will ask. The
log is also the only record of the peak-memory trace and of whether early
stopping fired.

If `run.log` is missing from the bundle, say so in the report rather than
inferring feature attribution from the arm names.

### Interpretation

| file | what it is for |
|---|---|
| `README.md` | The narrative source of record. §5 is what each GNN learns and what each arm sees; §6 is the results with four distinct readings; §4 is the engineering rationale |
| `SUMMARY.md` | Condensed version of the same |

### Provenance — include when the report must withstand scrutiny

| file | what it is for |
|---|---|
| `DECISIONS_LEAK_CONTROL.md` | Controls D0–D10. Lets the report say *why* each control exists, not merely that it does |
| `PLAN_VS_BUILT.md` | All 212 design commitments classified against the shipped code. The source for §4 below |
| `REFERENCES.md` | What was borrowed vs built. Prevents crediting this work to NVIDIA's kit or to tg-gnn |
| `ARCHITECTURE.md` | Pre-build design record, **preserved unedited** |
| `DECISIONS_DRAFT.md` | Pre-build decision record, **preserved unedited** |

### Deliberately excluded from the bundle

`artifacts/matrix/**` (22.5M rows), `artifacts/stage2/embeddings/`,
`artifacts/stage4/embeddings/`, `test_predictions_*.parquet`, the
`xgboost_*.json` boosters, and the 57 GSQL scripts. Every figure derived from
them is already in the results files above.

---

## 3. How to read `stage1_comparison.json`

Three top-level keys.

**`results`** — one entry per arm. Each carries `aucpr` (train/val/test),
`roc_auc`, `test_report` (with `aucpr_interval`, `at_threshold`
precision/recall/F1, and the confusion matrix), `val_report`,
`threshold_from_validation`, `best_iteration`, `n_features`, the full
`feature_names` list, `dropped_columns`, and rows/positives/prevalence per split.

**`lifts`** — one entry per comparison, each with `baseline`, `candidate`,
`absolute`, `relative`, `paired_interval`, `probability_candidate_better`, and a
**`claim` string**. *Read the `claim` string.* It is the written statement of what
that specific comparison establishes, and it is the correct basis for the
report's prose. Prefer it over inventing an interpretation.

**`notes`** — pre-empts the two commonest misreadings. Quote it if useful.

### Every lift has a baseline, and the baseline is the point

The arms are **nested**: each is a strict superset of a shallower one. A lift is
therefore attributable only against the arm that differs by exactly the thing
under test.

```
raw (19 cols)                          0.1711
└─ + aggregates (35)                   0.2051    +0.0341  significant
   └─ + graph (51)                     0.2150    +0.0098  significant, thin
      ├─ + temporal (60)               0.5631    +0.3482  THE RESULT
      │  └─ + TGN pair score (63)      0.5635    +0.0003  zero
      ├─ + R-GCN embeddings (179)      0.1919    −0.0231  worse
      ├─ + R-GCN pair score (54)       0.2161    +0.0011  zero
      └─ R-GCN instead of graph (163)  0.1924    −0.0226  worse
```

Not every lift is a nesting. Three shapes exist and the report should not
conflate them:

- **Nested addition** — candidate ⊃ baseline. Six of the nine lifts.
- **Substitution** — `+ graph → R-GCN instead of graph`. That arm *drops* the
  hand-built graph columns and keeps the embeddings, so it is not a superset. It
  asks whether the GNN can replace PageRank and entity resolution. −0.0226 = no.
- **Sibling repackaging** — `+ R-GCN embeddings → + R-GCN pair score`, 179 vs 54.
  Neither contains the other; both derive from the *same* vectors, once as 128 raw
  dimensions and once as 3 derived scalars. This is what isolates dilution from
  information content.

### The mechanism, stated once

The two findings are one mechanism. **Dilution is real; information content is
zero.** Compressing the same R-GCN vectors from 128 columns to 3 pair statistics
recovers **+0.0242** (significant) — so the wide form was diluting. But the
compressed form still adds only **+0.0011** over `+ graph` — so there was nothing
in the vectors XGBoost was not already receiving losslessly through the
star-schema join. Both encoders consume features the trees already have.

---

## 4. Original intent versus measured result

**This section must appear in the report.** The three pre-build documents in the
bundle describe a different project from the one that shipped, and they are
preserved unedited on purpose — annotating them in place would destroy the record
of what was decided before the evidence arrived. `PLAN_VS_BUILT.md` is the
reconciliation: **212 design commitments, 165 of them (78%) diverged**, and both
documents diverged by the same proportion (86 → 67, and 126 → 98).

### What `DECISIONS_DRAFT.md` and `ARCHITECTURE.md` specified

| # | Intended | Shipped | verdict |
|---|---|---|---|
| 1 | **Dataset: IBM TabFormer**, 24M transactions, ~30K fraud | A generated payment corpus via `tf_gnn_loader_v2`: **27,404,317 loaded**, 22,505,700 assembled, 68,618 cards / 1,027 merchants, 0.129% test prevalence — and PII vertices (`Party`, `Email_Address`, `Phone`, …) TabFormer has no columns for | changed |
| 2 | **Benchmark against NVIDIA's 0.79 / 0.90** — "Stage 1 ↔ 0.79", "Stage 2 ↔ 0.90" | **Not reference numbers for anything here.** Different dataset, so the comparison is within-dataset only | abandoned |
| 3 | **Split on NVIDIA's calendar years** (train <2018, val 2018, test >2018) | **6 forward-chaining builds on dense `event_seq`.** The loader stamped every training row `-2` and assigned no fold ≥ 0, so calendar cutoffs could not resolve | changed |
| 4 | **The solution kit's own GSQL feature queries, run as-is** | **57 GSQL scripts written for this project.** Schema r3 keeps the vertex/edge model but deletes the kit's 25 wide `Payment_Transaction` columns, and *no kit query runs unmodified* | changed |
| 5 | **tg-gnn for both GNN stages** — metadata dict, `torchrun`, multi-GPU cuGraph + cuGraph-PyG | **Not installed, not imported, not called.** Both stages train single-process on PyG against this repo's own exports. cuGraph is probed and never used | abandoned |
| 6 | **Stage 2 model: R-GCN**, to match NVIDIA's family | **Kept** — `HeteroConv` of per-relation `SAGEConv` with `aggr="sum"` | kept |
| 7 | **Stage 4 model: undecided** — "GAT / TGN / another temporal model, **pending NVIDIA**" | **TGN**, decided in-repo: `TGNMemory` + `IdentityMessage` + `TransformerConv` + `LastNeighborLoader`. No external input was awaited | changed |
| 8 | **Layout `ml/`, `gnn/`, `ml_temporal/`, `gnn_temporal/`, `eval/`**, each writing `metrics.json` + `model.pkl`/`model.pt`; `eval/compare.py` → `eval/report.{md,html}` | `src/tfgnn/` + `src/baseline/`; `artifacts/stage1/stage1_comparison.json`; `report.png`, not `report.html` | changed |
| 9 | **Four stages = four cells of a 2×2** | **Eight measured arms**, because the four-cell design could not separate dilution from information content, nor addition from substitution | changed |
| 10 | Host requires **NVIDIA GPU, CUDA ≥ 12.8, conda/Miniforge** (tg-gnn's constraints) | None of those are prerequisites. The binding constraint turned out to be **host RAM** — a lift run needs ~67 GiB peak after ~207 GiB of pandas waste was removed | changed |
| 11 | **Serving layer: open** | Still open. Offline benchmark only | unbuilt |

### The intent that mattered most, and how it inverted

The design's centre of gravity was item 2: reproduce a published GNN improvement.
Every stage was framed as "↔ NVIDIA's number", the dataset was chosen to make
that comparison possible, and the Stage 2 model was chosen to match NVIDIA's
family.

The measured outcome inverts it:

- The **GNN** contributes **nothing** (+0.0011 / +0.0003, both straddling zero),
  and its wide form **costs** −0.0231.
- The lift the project actually found — **+0.3482** — comes from a source the
  design documents barely mention: per-row backward-looking **temporal** features
  computed in GSQL, with no graph learning involved.
- The graph is not worthless, but it pays as **hand-specified features**:
  `+0.0098` for the graph block, and the single strongest graph feature is
  `cre_distinct_pii_count` from **entity resolution over the PII vertices** — a
  part of the schema TabFormer does not have, and therefore a part of the design
  that only became possible *because* item 1 changed.

**That is the finding to lead with for an engineering audience.** The project set
out to validate GNN-embeddings→XGBoost and instead produced a controlled
measurement that, on this corpus, the same graph pays through traversal-computed
features and not through learned ones. The 78% divergence in
`PLAN_VS_BUILT.md` is not a process failure to apologise for — it is what
following the evidence looked like.

### What `REFERENCES.md` establishes, and why the report needs it

It is the anti-misattribution document. Three claims the report must not make:

- **Not the solution kit's pipeline.** Its schema was the starting point; its
  feature queries and its `./model` are not what ships.
- **Not TabFormer, so not NVIDIA's numbers.** 0.79 and 0.90 are context. The
  same caveat is written into every `stage1_comparison.json` by the trainer.
- **Not tg-gnn, and not multi-GPU.** `"cugraph": true` in `stage4_metrics_*.json`
  means *available*, not *used*: median step time was ~69 ms both with it absent
  and with it installed-but-unused, and Stage 2 refuses `--backend cugraph`
  outright.

---

## 5. Five traps. Each has already caught a careful reader.

### 5.1 A ranked AUC-PR table makes the R-GCN look like a win

`+ R-GCN embeddings` scores **0.1919**, above `raw`'s **0.1711**. Read from the
table alone, the GNN helped. It did not: that arm is a strict superset of
`+ graph` (0.2150), so its lift is **−0.0231**. The +0.0208 over `raw` is the 51
inherited graph columns being credited to the encoder.

If the report includes an absolute-score table, put the lift and its baseline in
the same row.

### 5.2 `+ TGN embeddings` was never measured

There is a row for it — 260 features — marked **not measured**. It was excluded
with `--exclude raw_plus_temporal_embeddings` because the 200-column TGN block
plus the matrix exceeded available RAM. Do not fill that cell, do not estimate
it, and do not quietly drop the row. Its *question* is answered by the pair-score
arm, and that substitution should be stated rather than glossed.

### 5.3 Stage 4a's 0.3241 is not comparable to any XGBoost arm

Stage 4a trains a supervised head on `is_fraud`. Its embeddings are written to
`embeddings_fraud/` specifically so the lift table cannot read them. Two further
qualifications:

- Its **251×** is partly not the graph. `FraudHead` receives the transaction's own
  54 raw numbers **directly**, bypassing memory — so the strongest feature in the
  project reaches it without any message passing.
- The 0.3824 → 0.3241 move between two Stage 4a runs is **not** attributable to
  the attention fix. Those runs differed in seed *and* scoring regime; a `--seed`
  flag was added afterwards.

### 5.4 Prevalence is 0.129%, so read every score against 0.00129

Random guessing scores **0.00129** AUC-PR. `0.5631` is **436×** that, not "56%
accurate". And **ROC-AUC reads ~0.91 for every arm and separates nothing** —
which is why AUC-PR is the primary metric. A report that leads with ROC-AUC has
reported that all eight arms are equivalent.

### 5.5 The strongest single feature may be an artifact of the generator

The largest contributor is *"has this card used this merchant before"*: first
visits are **11.3× more likely** to be fraud, and half of all fraud sits in 8% of
rows. The corpus is **synthetic**. The *direction* is credible and matches real
card-fraud behaviour; the *magnitude* is a property of how fraud was injected and
should not be promised to production. State this explicitly — an engineering
audience will discover it the first time they run against real data.

---

## 6. Method facts worth stating, because they are what make the numbers mean anything

- **Every arm trained and scored on byte-identical rows**, split by `split_id`
  from TigerGraph. This is the project's non-negotiable "no pollution rule" and
  it is what makes this a comparison rather than eight experiments.
- **Intervals are paired percentile bootstraps of the difference** — both arms
  resampled with the same row weights on each draw. Not two independent CIs
  subtracted.
- **The threshold behind every F1 and confusion matrix was chosen on validation
  and applied unchanged to test.**
- **Metrics come from the reloaded saved JSON model**, not the in-memory booster,
  with the round-trip max-abs-diff recorded.
- **Forward chaining**: 6 builds, each fitted strictly below its own
  `cutoff_event_seq` and serving only rows at or after it. No training row reads a
  feature fitted over a window containing itself.
- **The test set is 36.4% inductive** — 552,579 of 1,519,190 test rows carry a
  card or merchant absent from training (41.1% of test cards). So cold-start
  generalisation is *demonstrated*, not assumed. Cite
  `assemble.inductive_reach`, and note this reverses a caveat that stood in the
  docs until 2026-08-04.
- **Everything graph-shaped runs inside TigerGraph.** PageRank, WCC, entity
  resolution, community statistics, aggregates and the temporal features are all
  GSQL. Nothing is downloaded to be computed client-side. This is what makes the
  result a statement about TigerGraph rather than about pandas.

---

## 7. Open items — state them; do not let the report imply completeness

- `raw_plus_temporal_embeddings` (260 columns) unmeasured — RAM.
- Stage 4's `LinkHead` does **not** implement D5's mandatory negative-sampling
  collision check. Stage 2 does, and measured the collision rate at **3.9%**.
- Stage 4 does **not** rank-normalise embeddings within build; Stage 2 does, and
  its own docstring calls that step conditional-mandatory when more than one
  snapshot exists. Stage 4 writes six. Effect untested, since the wide TGN arm
  was never measured.
- `tgn_window_neighbors.gsql` is installed and **never called** — the getvid →
  model-index map it needs is not built. Stage 4 seeds its adjacency from the
  stream instead, which is correct but cold.
- D7's `permutation_control.gsql` — the ground-truth leak test — has never been
  run.

---

## 8. Tone

Write for engineers who will maintain this. Prefer the measured number and its
interval over an adjective. Where a result is negative, say so in the same
sentence as the number. Where something was not measured, name it. The
credibility of the +0.3482 rests entirely on the fact that the −0.0231 was
reported too.
