# Decisions draft

These are the step-by-step action items / Stories for implementing this solution. They need to be as clear as possible and they must be followed exactly as is. Anything that is not defined or not clear in this doc must be raised, designed, and added to this doc. This will be the base for the SDD (Solution Design Document) and is itself based on the SRD.

---

## Designed, Under Review

### 1. Dataset
**IBM TabFormer.** 24M synthetic credit-card transactions, 30K labeled fraud. Marketing-recommended; NVIDIA's 2022 GNN blog uses the same dataset, so we have a published reference number (AUCPR 0.79 XGBoost-alone vs 0.90 GNN+XGBoost).

### 2. Data split
- Three sets: **train / val / test**.
- **Temporal** by `unix_time`.
- **Same split** used by every stage in Section 3 (all four) — same train rows, same val rows, same test rows. The whole point of the comparison.
- Boundaries: **match NVIDIA's split** — train = before 2018, val = during 2018, test = after 2018. Reason: direct comparability with NVIDIA's published AUCPR.

> **🚩 NO POLLUTION RULE — non-negotiable.** Every stage must train on exactly the same train rows, validate on exactly the same val rows, and test on exactly the same test rows. **Not a single transaction can differ across the four stages.** No stage's training graph may contain rows from another stage's val or test split. This is the only thing that makes the four-stage comparison honest.
>
> Stories 4, 5, and 6 each open with a "prep clean training-ready state" sub-task that gives three options for how to satisfy this rule (fresh instance / snapshot+restore / reuse-with-verification). Picking one is per-stage and can vary.

### 3. Four-stage comparison
All four stages run on **TigerGraph + the solution kit** (kit schema, kit's GSQL feature queries). The variable is what sits on top.

| Stage | Setup | Purpose |
|-------|-------|---------|
| **Stage 1: XGBoost only** | Load TabFormer into kit schema → kit's GSQL feature queries → XGBoost on those features. No GNN. | Baseline. |
| **Stage 2: GNN + XGBoost** | Same as Stage 1, plus tg-gnn trains a GNN over the kit schema; GNN embeddings feed into XGBoost. | Shows what GNN adds on top of the kit. |
| **Stage 3: Temporal + XGBoost (no GNN)** | Same data and schema as Stage 1, plus temporal feature modeling on the tabular path; those features feed XGBoost. No GNN. | Shows what temporal modeling adds *without* a graph. |
| **Stage 4: Temporal + GNN + XGBoost** | Same data and schema as Stage 2, but the GNN is temporal; temporal GNN embeddings feed XGBoost. | Shows what temporal modeling adds on top of the GNN. Separate later step. |

> **Temporal model — not final.** The temporal GNN model for Stage 4 is not yet decided. We're checking with NVIDIA whether it's **GAT**, **TGN**, or **another temporal model**; to be finalized later. See Open item A.

### 4. GNN model choice for Stage 2
**Recommendation: R-GCN.** Alternative considered: GraphSAGE.

Reasons R-GCN wins:
1. **Comparison baseline.** NVIDIA used R-GCN on TabFormer. Using the same model family lets us compare numbers directly (with the caveat noted in Section 6 below).
2. **Fits the kit schema.** The kit has six vertex types and multiple edge types (cardholder→card, card→transaction, transaction→merchant, merchant→category, etc.). R-GCN is built for heterogeneous graphs — it learns different weights per edge type. GraphSAGE would work but throws away the relational signal.

### 5. Metrics
Match NVIDIA's reporting. They reported AUCPR only.

- **Required: AUCPR** (area under precision-recall curve; same as AUPRC). NVIDIA's metric, and the right primary metric for severely imbalanced fraud (~0.1% positive rate). The comparison number.
- **Optional (report if convenient, drop under scope pressure):**
  - ROC-AUC — standard, but inflates on imbalanced data.
  - F1 at the chosen threshold.
  - Confusion matrix at the chosen threshold.
  - Inference latency (rows/sec, same hardware for all four stages).

Reported per stage (XGBoost only / GNN+XGBoost / Temporal+XGBoost / Temporal+GNN+XGBoost) on the **same test split**.

### 6. Comparison caveat
Our R-GCN comparison vs NVIDIA's 0.90 is **same model family, different graph**:
- NVIDIA's graph: minimal, card_id ↔ merchant_id only.
- Our graph: solution kit's six-vertex schema with the kit's GSQL features.

This caveat must be stated in the final report. If we beat 0.90, the credit goes to "TigerGraph schema + R-GCN," not to R-GCN alone — which is the story we want anyway.

---

## Action items (assignable stories)

A story is **atomic** when it's small and cohesive enough that one person owns it end-to-end. Larger stories below have sub-tasks for execution clarity, but each sub-task is still small enough to be one person's deliverable.

### Story 0 — Planning docs
Consolidate this draft into two formal documents.

- **0a. Solution Requirement Document (SRD).** What we're building and why. Includes: problem statement, success criteria, dataset choice, constraints (TigerGraph + tg-gnn + NVIDIA GPUs, no AWS), metrics, comparison targets (NVIDIA's 0.79 / 0.90).
- **0b. Solution Design Document (SDD).** How we'll build it. Includes: architecture, data flow, schema mapping (TabFormer → kit), stack (TG, tg-gnn, R-GCN, XGBoost, TGN), repo layout, Makefile surface.
- **0c. Roadmap update.** Promote finalized decisions from this draft into `docs/ROADMAP.md`. Revise dataset constraint in `CLAUDE.md` / `README.md` / `REFERENCES.md` to allow TabFormer.
- **0d. Stories/tasks register.** Hand off this action-items list into whatever tracker we use (Jira / Linear / GitHub issues).

**Done when**: SRD and SDD exist; roadmap reflects the four-stage plan; constraint docs no longer block TabFormer; all stories below exist as tickets.

---

### Story 1 — Split logic + validation (atomic)
Build the temporal split tooling. Produce a manifest listing which TabFormer rows go to train / val / test based on NVIDIA's year cuts (pre-2018 / 2018 / post-2018).
**Done when**: row-ID lists for the three splits exist; row + fraud counts per split reported; no row in more than one split.

---

### Story 2 — Align the solution kit with TabFormer
The kit's schema, loading job, edge-building queries, algorithm wrappers, and ML feature
generators were written for a richer dataset than TabFormer provides. This story makes the
kit consistent with TabFormer in both directions: add what TabFormer has and the schema
lacks, featurize it, and document what the schema expects but TabFormer can't fill.
[`TABFORMER_MATRIX.md`](TABFORMER_MATRIX.md) gives a first-pass element-by-element analysis
(Table 1 = schema vs TabFormer, Table 2 = query status, Table 3 = queries that depend on
missing data) — it's a starting point, not a complete inventory, so treat its lists as
illustrative and verify against the actual kit queries.

- **2a. Extend the schema for TabFormer-only fields.** TabFormer carries fields with no
  schema slot today, such as `Use Chip`, `Errors?`, `Merchant City`, `Merchant State`,
  and `Merchant Zip`. For each, decide whether it becomes a `Payment_Transaction`
  attribute or a new node/edge, and add the slots. Stay within the schema-extension rule
  (extend only where needed; don't import a second dataset's model).
  **Done when**: the schema has slots for the TabFormer-only fields; each placement
  decision is documented.
- **2b. TabFormer loading job.** Write the GSQL loading job that maps TabFormer CSV
  columns onto the kit's schema (including 2a's new slots). Nothing else — no install, no
  execution. Just the loading-job definition.
  **Done when**: a `loading_job` GSQL file exists that, when run against a TG with the
  kit's schema, would ingest TabFormer's train slice (per Story 1's manifest).
- **2c. Investigate missing-data impact and plan adjustments.** [`TABFORMER_MATRIX.md`](TABFORMER_MATRIX.md)
  is a high-level first pass at what TabFormer can't fill. Do the detailed version: go
  through all the queries — edge builders, algorithm wrappers, and ML feature generators —
  and assess how the missing data actually affects each one. Rate the severity/impact, then
  plan accordingly: for each affected query decide whether it must be replaced, adjusted, or
  left as-is (and documented as inactive). This plan is what 2d–2f execute.
  **Done when**: every query is assessed for missing-data impact with a severity rating;
  there's a per-query plan (replace / adjust / leave) covering edges, algorithms, and
  features.
- **2d. Review the edge-building queries.** Check the edge builders (such as
  `card_card_with_weights` and `merchant_merchant_with_weights`) against the new TabFormer
  data and decide whether any new field should influence how edges or their weights are
  built.
  **Done when**: each edge builder is reviewed; any change to incorporate new data is made
  or explicitly deferred with a reason.
- **2e. Review the algorithm wrappers.** Check the algorithm wrappers (including but not
  limited to the WCC and PageRank wrappers) and decide whether the new TabFormer data
  should feed community formation or any other algorithm.
  **Done when**: each wrapper is reviewed; decisions on using new data in communities /
  other algorithms are documented.
- **2f. Generate ML features from the new data.** Author the feature logic that turns
  2a's new fields into model inputs (the gap analysis flags `Errors?` and `Use Chip` as
  the real new-signal upside). These are net-new feature queries beyond the kit's
  original set.
  **Done when**: new feature queries exist and write to `Payment_Transaction`; non-null
  sanity checks pass on the train slice.
- **2g. Document queries that depend on data TabFormer lacks.** Some edge builders,
  algorithm wrappers, and ML feature generators read schema elements TabFormer leaves
  empty — such as Party PII and demographics (`age`, `gender`, `city_pop`, `occupation`).
  Identify these and document that they won't work on TabFormer (and why). Do not remove
  them — the kit keeps them for richer datasets; we just record which ones are inactive on
  this dataset.
  **Done when**: there's a documented list of queries that don't work on TabFormer, with
  the missing data each one needs.

**Done when**: schema, loading job, edge-building queries, algorithm wrappers, and ML
feature generators are all reviewed and consistent with TabFormer — new fields added and
featurized, unfillable ones documented.

---

### Story 3 — Stage 1: XGBoost baseline
Higher-level sub-stories. Each is one person's deliverable.

- **3a. Prep the solution kit.** Install the solution kit, install its GSQL queries, run the loading job from Story 2b against TG, validate the data is loaded correctly (vertex / edge counts match Story 1's manifest, spot-check column mapping).
  **Done when**: TG holds the train slice; all kit queries are installed; data load validated.
- **3b. Run the kit's GSQL pipeline.** Execute the kit's three query layers in order, test that each step works, validate the outputs:
  - Edge-building (`card_card_with_weights`, `merchant_merchant_with_weights`)
  - Algorithm wrappers (`tg_wcc_card_weight_based`, `tg_wcc_merchant_weight_based`, `tg_pagerank_wt_card`, `tg_pagerank_wt_merchant`)
  - Feature engineering (`community_size`, `*_shortest_path_length`, `card_merchant_max_amount_within_interval`, `number_of_repeated_card`, `community_transaction_*`, `merchant_category_*`, `degrees`, demographics)
  
  After the pipeline finishes, **take a TG snapshot** (`gadmin backup` or equivalent). TG is now in the clean "training-ready" state — train rows loaded, kit features computed, no val/test data present. Stories 4, 5, and 6 can restore from this snapshot.
  
  **Done when**: ~25 features present on `Payment_Transaction` train rows; non-null sanity checks pass; snapshot saved with a known name (e.g., `training_ready_v1`).
- **3c. Metrics module (shared utility).** Implements Section 5 metric set (AUCPR / ROC-AUC / F1 / confusion matrix / inference latency). **Used by Stories 3, 4, and 5** — built here because Stage 1 is the first consumer.
  **Done when**: module exists; unit-tested; integration-tested by Stage 1's eval step.
- **3d. ML training (train + validate + test).** Single ML workflow. pyTigerGraph pulls features from TG as a DataFrame (kit's native pattern, no export). Train XGBoost on train rows (kit defaults: `scale_pos_weight=10, n_estimators=50, learning_rate=0.1, max_depth=3` — starting point). Tune hyperparameters against val AUCPR. Run final eval on test split, call 3c to compute metrics, write `ml/metrics.json`.
  **Done when**: `xgboost.json` model + `ml/metrics.json` (Section 5 metrics on test split) + locked hyperparameter set documented.
- **3e. Document.** Stage-level write-up: which queries were run, hyperparameters used, where the numbers come from. Feeds Story 7's consolidated report.
  **Done when**: `ml/RUN_NOTES.md` exists.

**Done when**: all sub-stories complete; `ml/metrics.json` + `ml/RUN_NOTES.md` exist.

---

### Story 4 — Stage 2: R-GCN + XGBoost
Recommend R-GCN per Section 4. Alternative GraphSAGE.

- **4a. Prep — get TG into the clean training-ready state.** End state is the same as the end of Story 3b: train rows loaded, all kit GSQL queries run, ~25 features computed on `Payment_Transaction`, **no val/test rows present**.
  **Decision (2026-06-09): Option 1 — fresh instance.** The options below are kept for context, but the chosen mechanism is a fresh install (re-run Story 3a + 3b on a new TG).
  
  Three acceptable options:
  - **Option 1 — Fresh instance.** Spin up a new TG instance and re-run Story 3a + 3b end-to-end on it.
  - **Option 2 — Restore Story 3b's snapshot.** Restore the `training_ready_v1` snapshot saved at the end of Story 3b into a TG instance.
  - **Option 3 — Verify-and-reuse an existing instance.** If reusing the TG instance Story 3 used, run a verification query first: `SELECT count(*) FROM Payment_Transaction WHERE unix_time >= train_cutoff` — must return zero. If anything fails verification, fall back to Option 1 or 2.
  
  Story 3c (metrics module) is reused regardless of which option is picked.
  
  **Done when**: TG holds train rows + kit features only; verification query returns zero val/test rows.
- **4b. Feature selection.** For each kit feature on `Payment_Transaction`, decide: (i) goes to GNN as a node/edge feature, (ii) stays tabular-only for downstream XGBoost, or (iii) both. Document choices.
  **Done when**: `gnn/FEATURE_SELECTION.md` exists.
- **4c. Schema → tg-gnn metadata.** Translate the kit's schema into a tg-gnn `metadata` dict (vertex types, edge types, `features_list` per 4b, label, split, `time_attr`).
  **Done when**: `gnn/metadata.py` exists.
- **4d. tg-gnn export.** Run tg-gnn's export against TG using 4c's metadata. Verify `data_dir` is valid input for PyG.
  **Done when**: `data_dir` populated; smoke test loads it into PyG without error.
- **4e. R-GCN training loop.** torchrun entrypoint over `data_dir`, training R-GCN via link prediction (NVIDIA-style). Multi-GPU via `--nproc-per-node`. Save model + node embeddings.
  **Done when**: `gnn/model.pt` + `gnn/embeddings.pt` exist; training loss / val AUCPR logged.
- **4f. Embeddings join + ML training (train + validate + test).** Join R-GCN embeddings onto `Payment_Transaction` rows. Train XGBoost on `[kit features + embeddings]`, tune on val, evaluate on test. Call Story 3c's metrics module. Write `gnn/metrics.json`.
- **4g. Document.** Stage-level write-up. Feeds Story 7.
  **Done when**: `gnn/RUN_NOTES.md` exists.

**Done when**: `gnn/metrics.json` + `gnn/RUN_NOTES.md` exist, same test split as Story 3.

---

### Story 5 — Stage 3: Temporal + XGBoost (no GNN)
Temporal modeling on the tabular / XGBoost path — no graph, no GNN. Isolates the contribution of time-awareness on its own, before the temporal GNN stage. Same train/val/test split as every other stage.

- **5a. Prep — get TG into the clean training-ready state.** Same end state and three options as Story 4a.
  **Decision (2026-06-09): Option 1 — fresh instance**, consistent with Story 4a.
  
  Options:
  - **Option 1 — Fresh instance.** Re-run Story 3a + 3b on a new TG.
  - **Option 2 — Restore Story 3b's snapshot.** Restore `training_ready_v1`.
  - **Option 3 — Verify-and-reuse.** Confirm `count(Payment_Transaction WHERE unix_time >= train_cutoff) == 0` on the existing instance.
  
  Story 3c (metrics module) is reused.
  
  **Done when**: TG holds train rows + kit features only; verification returns zero val/test rows.
- **5b. Temporal feature engineering.** Build time-aware features on `Payment_Transaction` from `unix_time` (e.g. recency, inter-transaction gaps, rolling-window velocity per card and per merchant). Tabular only — no graph embeddings.
  **Done when**: temporal features present on train rows; non-null sanity checks pass; feature list documented.
- **5c. ML training (train + validate + test).** Train XGBoost on `[kit features + temporal features]`, tune on val AUCPR, evaluate on test. Call Story 3c's metrics module. Write `ml_temporal/metrics.json`.
  **Done when**: model + `ml_temporal/metrics.json` (Section 5 metrics on test split) + locked hyperparameters documented.
- **5d. Document.** Stage-level write-up. Feeds Story 7.
  **Done when**: `ml_temporal/RUN_NOTES.md` exists.

**Done when**: `ml_temporal/metrics.json` + `ml_temporal/RUN_NOTES.md` exist, same test split as Stories 3 and 4.

---

### Story 6 — Stage 4: Temporal + GNN + XGBoost
The temporal GNN stage. **Model not final** — we're checking with NVIDIA whether it's **GAT**, **TGN**, or **another temporal model**; to be finalized later (see Open item A). Sub-tasks below are best-guess based on what we know now — expect to revise once the model is picked and after Story 4 finishes.

- **6a. Prep — get TG into the clean training-ready state.** Same three options as Story 4a.
  **Decision (2026-06-09): Option 1 — fresh instance**, consistent with Story 4a.
  
  Options:
  - **Option 1 — Fresh instance.** Re-run Story 3a + 3b on a new TG.
  - **Option 2 — Restore Story 3b's snapshot.** Restore `training_ready_v1`.
  - **Option 3 — Verify-and-reuse.** Confirm `count(Payment_Transaction WHERE unix_time >= train_cutoff) == 0` on the existing instance.
  
  Story 3c (metrics module) is reused. Story 4b (feature selection) results are a starting point; revisit for the chosen temporal model's needs.
  
  **Done when**: TG holds train rows + kit features only; verification returns zero val/test rows.
- **6b. tg-gnn × temporal-model feasibility spike.** Confirm tg-gnn's temporal sampler supports the chosen model (e.g. TGN's memory module), or scope the extension. **Blocker for the rest of Story 6** — could change everything below, and depends on the final model choice.
- **6c. Temporal metadata.** Extend the metadata dict from 4c with the chosen model's fields (e.g. memory size, time encoding, message/attention function).
- **6d. Temporal GNN training loop.** torchrun entrypoint, temporal neighbor sampling enforced (no future leakage). Save model + embeddings.
- **6e. Embeddings join + ML training (train + validate + test).** Mirror 4f. Write `gnn_temporal/metrics.json`.
- **6f. Document.** Feeds Story 7.
  **Done when**: `gnn_temporal/RUN_NOTES.md` exists.

**Done when**: `gnn_temporal/metrics.json` + `gnn_temporal/RUN_NOTES.md` exist, same test split as Stories 3, 4, and 5.

---

### Story 7 — Comparison report (atomic)
Read all four `metrics.json` files; produce `eval/report.md` and `eval/report.html` with side-by-side metrics + plots + Section 6 caveat.
**Done when**: report exists; a reader can see the four-stage comparison without reading any code.

---

## Open

### A. Temporal GNN model for Stage 4 — NOT FINAL
The temporal GNN model (Stage 4 / Story 6) is **not yet decided.** We're checking with NVIDIA whether it's **GAT**, **TGN**, or **another temporal model**; to be finalized later. Candidate so far: **TGN** (PyG `TGNMemory`) — per Marketing's note, this is what financial institutions are moving to — but it is not locked. Whatever we pick, we need to confirm tg-gnn supports it or that we can extend it; PyG has a TGN example, but tg-gnn's documented temporal example is GraphSAGE-style sampling, not TGN's memory module.

### B. Schema mapping — TabFormer → solution kit
TabFormer is flat tabular (User, Card, Year, Amount, Merchant Name, Merchant City, MCC, etc.). The kit's schema is six vertices (Cardholder, Credit_Card, Payment_Transaction, Merchant, Merchant_Category, Location). The mapping is straightforward in places (Card → Credit_Card, Merchant Name → Merchant) but lossy in others (TabFormer has no separate Cardholder demographics in the same form). Mapping logic is part of the loading job we'll write.

### C. No-pollution enforcement — resolved
Decided internally: **Option 1, fresh instance**, for both Story 4a and Story 5a. Snapshot-restore and verify-and-reuse were considered (still documented in 4a) but not chosen. Kept here as an open item despite being resolved, given the severity of train/test pollution — to emphasize its importance and ensure the decision isn't accidentally reversed.
