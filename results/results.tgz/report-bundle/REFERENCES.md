# Upstream references

A catalog of the external sources TF-GNN draws on — what each one is, its link, and how it relates to the others. **Reference only.** For how these pieces are assembled into the project, see [`ARCHITECTURE.md`](ARCHITECTURE.md) (system + seams) and [`DECISIONS_DRAFT.md`](DECISIONS_DRAFT.md) (decisions, source of truth).

## In scope — code and data we build on

### TigerGraph Transaction Fraud solution kit

https://github.com/tigergraph/solution_kits/tree/main/financial_crime/transaction_fraud

The starting point. Graph-powered credit-card fraud detection on TigerGraph 3.x/4.x: a GSQL schema, GSQL feature-engineering queries (co-occurrence edges, WCC, PageRank, and per-transaction features), a downstream classical ML model in `./model`, and Insights JSON dashboards.

**We started from its schema and diverged.** Schema r3 keeps the vertex/edge model but deletes the kit's 25 wide `Payment_Transaction` feature columns, and `gsql/schema/schema.gsql:403-404` records that *no kit query runs unmodified*. The feature pipeline that ships is this project's own — 57 GSQL scripts under `gsql/`: entity resolution, bipartite projection, forward-chaining builds, `card_row_temporal`, `tgn_window_neighbors`. The classical baseline is `src/baseline/train_xgboost.py` under `config.yaml`'s `model:` block; the kit's `./model` is not vendored here.

The authoritative schema-to-column contract is `gsql/schema/schema.gsql` (the DDL of record, schema r3) plus `src/tfgnn/features_meta.py` — the single place both sides of the export join are named.

### IBM TabFormer dataset — reference only, NOT our data

https://github.com/IBM/TabFormer

TabFormer is 24M synthetic credit-card transactions, ~30K labeled fraud, ~100K cards / ~6K merchants — the dataset NVIDIA's 2022 blog benchmarks on. **We do not use it.** Our corpus is loaded by `tf_gnn_loader_v2`: 27,404,317 transactions loaded, 22,505,700 assembled into the matrix, 68,618 cards / 1,027 merchants, fraud prevalence 0.129% on test. Schema r3 also carries PII vertices (Party, Birthdate, Email_Address, Phone, Identity_Document, Street_Address) that TabFormer has no columns for — and entity resolution over them is where the graph lift actually comes from.

Because this is not TabFormer, **NVIDIA's 0.79 / 0.90 are not reference numbers for any run in this repo.** The same caveat is written into every `stage1_comparison.json` by `src/baseline/train_xgboost.py`.

### TigerGraph tg-gnn — evaluated, not used

https://github.com/tigergraph/tg-gnn

**Nothing in `src/` imports tg-gnn**, `requirements.txt` does not list it, and there is no `torchrun` or distributed init anywhere in the repo. Both GNN stages export from TigerGraph with this project's own code (`src/tfgnn/tigergraph/export.py`, `gsql/export/export_graph_edges.gsql`, `gsql/topology/tgn_window_neighbors.gsql`) and train single-process on PyG. Its CUDA ≥ 12.8 / conda requirement is **not** a setup prerequisite for this repo.

For reference, tg-gnn is a bridge that uses TigerGraph as the graph store and trains GNNs multi-GPU via RAPIDS `cuGraph` + `cuGraph-PyG` (PyTorch). Integration is metadata-driven: a Python `metadata` dict declares the vertex/edge types, per-attribute feature lists, label, split, and optional `time_attr`; tg-gnn then exports from TG and a distributed PyG script trains on the export. Ships `torchrun` example entrypoints (including a temporal-split / temporal-sampling example) and loading notes in `benchmark/Benchmark.md`.

## Methodology references — the recipe we match

### NVIDIA blog — "Optimizing Fraud Detection in Financial Services with GNNs and NVIDIA GPUs" (2022) — primary reference

https://developer.nvidia.com/blog/optimizing-fraud-detection-in-financial-services-with-graph-neural-networks-and-nvidia-gpus

The published recipe our contract mirrors (GNN embeddings → XGBoost). On transactions-only TabFormer with a minimal card ↔ merchant graph, plain XGBoost scores **0.79 AUCPR** and the same XGBoost augmented with R-GCN node embeddings scores **0.90** — measured on TabFormer, which is not our corpus, so these are context, not our targets. Our comparison is within-dataset: raw 0.1711 → + aggregates 0.2051 → + graph 0.2150 → + temporal 0.5631. NVIDIA's 2022 implementation was DGL + RAPIDS cuDF + Triton on DGX A100. (How we mirror it — and where we deliberately differ — is in [`DECISIONS_DRAFT.md`](DECISIONS_DRAFT.md).)

### NVIDIA blog — "Supercharging Fraud Detection in Financial Services with GNNs" (2024, updated 2025) — additional resource

https://developer.nvidia.com/blog/supercharging-fraud-detection-in-financial-services-with-graph-neural-networks/

The productized successor to the 2022 blog — NVIDIA's AI Blueprint for financial fraud detection. Same GNN-embeddings → XGBoost contract, but uses **GraphSAGE** rather than R-GCN, and publishes **no comparable AUCPR** (only a qualitative "GNN + XGBoost beats XGBoost alone"). Context, not a benchmark target: useful as confirmation that GNN → XGBoost is NVIDIA's current production recommendation, and as a reference for inference/serving if we extend past the offline benchmark.

## Reference only — Makefile ergonomics

### AWS sample-financial-fraud-detection-with-nvidia, `feature/neptune-graph-backend` branch

https://github.com/aws-samples/sample-financial-fraud-detection-with-nvidia/tree/feature/neptune-graph-backend

We do **not** use this repo's code, stack, dataset, or architecture. The only thing we look at is its root **Makefile**, as a precedent for clean one-command ergonomics. We design our own Makefile around our own stack and target names.

## Out of scope

We do not use, and are not coupled to, any AWS-specific service: CDK, SageMaker, Triton, NGC, ECR, S3, Neptune, EC2/EKS. (These appear in the AWS sample above because that's what *it* uses.) If a future workshop needs a cloud deploy, it's an additive layer, not a project constraint.

## How the references relate

- The **solution kit** supplied the starting schema. Its feature pipeline and its ML model are not what ships: schema r3 drops the wide transaction columns, no kit query runs unmodified, and the 57 GSQL scripts under `gsql/` are this project's own.
- **IBM TabFormer** is the dataset the NVIDIA reference numbers were measured on, **not** the data in this repo's graph.
- **tg-gnn** is reference only — not installed, not imported, not called. Stage 2 (PyG `HeteroConv` + `SAGEConv`) and Stage 4 (PyG TGN: `TGNMemory` + `TransformerConv` + `LastNeighborLoader`) train single-process on exports produced by this repo's own GSQL. **cuGraph is probed, never used:** `cugraph_sampler.build_store()` is never called, so `"cugraph": true` in `stage4_metrics_*.json` means *available*, not *used* — median step time was ~69 ms both with it absent and with it installed-but-unused, and Stage 2 refuses `--backend cugraph` outright.
- The **NVIDIA 2022 blog** is the methodology we mirror (GNN embeddings → XGBoost). The dataset differs, so the numbers are **not** comparable — see README §7; the **2024 blog** is its productized successor, kept for context.
- The **AWS sample** contributes nothing but a Makefile-ergonomics precedent.

The current system, the engineering choices and the measured results are in [`../README.md`](../README.md) and [`../SUMMARY.md`](../SUMMARY.md).

[`ARCHITECTURE.md`](ARCHITECTURE.md) and [`DECISIONS_DRAFT.md`](DECISIONS_DRAFT.md) are the **pre-build design records, preserved unedited**. They are superseded on many specifics and should not be read as descriptions of the code. [`PLAN_VS_BUILT.md`](PLAN_VS_BUILT.md) is the reconciliation: every design commitment in those two documents, classified against what was actually built, with the reason for each departure.
