# Updated decisions: val/test residency and leak control

Supersedes `DECISIONS_DRAFT.md` §2 no-pollution rule, Open item C, and the "prep clean training-ready state" sub-task in Stories 4a, 5a and 6a.

Status: proposed. Requires sign-off because it reverses a decision that was explicitly recorded as resolved-and-do-not-reverse.

---

## D0. One requirement is rejected

"No leak from training into test" is not a leak condition and is not implemented.

Training information flowing into test features is what production does. A February 2019 test transaction reading its card's 2017 PageRank is reading its own past. Forbidding it leaves test rows with no graph features and the project with nothing to measure.

The real hazard under that phrasing is **model-selection coupling**: hyperparameters are tuned on validation, so if validation-period labels also feed test features, the test estimate is no longer independent of the tuning. This is why arms B (strict labels) and C (operational labels) are reported separately and never merged. Named here so nobody re-derives the wrong constraint later.

---

## D1. Validation and test rows are resident in the graph. Fresh-instance exclusion is retired.

**Decision:** all rows for all splits load into one TigerGraph instance. `split_id` and `event_seq` distinguish them. The Story 4a/5a/6a verification query (`count(Payment_Transaction WHERE unix_time >= train_cutoff) == 0`) is deleted.

**Rationale, and it is stronger than convenience:**

Exclusion makes leak-free features *impossible*, not merely awkward. A test transaction's card-level degree requires an edge from that transaction to a Card that also appears in training. If the transaction is absent during feature fitting, the feature can only be attached later by re-running a query over a graph that now contains it, which refits on evaluation data, or by an external join whose correctness nothing in the graph can check.

Second, decisive: the Stage 4 temporal sampler needs val/test transactions **present as seeds** while sampling only earlier neighbors. Temporal samplers build the k-hop subgraph around a seed and timestamp, admitting only elements at or before that timestamp <cite index="61-1">so the subgraph contains no future information</cite>. A seed that is not in the graph cannot be sampled around. Exclusion makes Stage 4 unimplementable.

**What is lost:** fresh-instance residency was the *enforcement mechanism*. It made leakage structurally impossible for the projection queries by making the offending rows unreachable. Removing it converts a structural guarantee into a discipline problem. D2 and D3 replace it.

---

## D2. The export is the enforcement boundary, and exclusion is edge-level not row-level

**Decision:** three exclusions are enforced, at different layers. They are independent and fail differently. Conflating them is how projects leak while believing they are safe.

| | What it forbids | Enforced where | Failure mode |
|---|---|---|---|
| **Row** | val/test rows in a training label set | `split_id` filter in the trainer | loud; row counts mismatch |
| **Fitting** | val/test rows contributing to any *fitted* quantity | `event_seq < cutoff` in every GSQL builder | **silent; better number** |
| **Traversal** | message-passing paths from a training seed to a later vertex | export-time edge masks | **silent; better number** |

Row exclusion was the only one fresh-instance actually protected, and it was never the hard one.

**Fitting exclusion.** Every projection, PageRank, community, aggregate and encoding builder filters on `edge.event_seq < build.topology_cutoff_event_seq`. Already in schema r2. The gap is that a forgotten predicate produces no error and a better result. Mitigation: builders traverse `Has_Interaction_Work`, which is itself materialised under the cutoff, so a builder reading the work projection cannot reach a post-cutoff row even if its author forgets a predicate. Direct traversal of `Card_Send_Transaction` inside a projection builder is prohibited by review, not by the schema.

**Traversal exclusion.** Handled at export, per D3.

**Statistical fitting on the tabular side counts as fitting exclusion.** Normalisation constants, target encodings and category aggregates must be computed per split from past data only <cite index="32-1">rather than once over the whole dataset</cite>. `DECISIONS_DRAFT` Story 3d's "train-fitted categorical encodings" is correct in intent; add that the fitting set is the *fold's* training window, not the whole training split, or the encoding leaks across folds within training.

---

## D3. Traversal exclusion: yes, more is needed. Per-snapshot export is not sufficient.

You asked whether per-snapshot export already isolates this. It does not, for four separate reasons.

### 3a. Untimestamped relations are sampled without any temporal constraint

This is the most dangerous finding and it is a documented framework behaviour, not a bug. In PyG's temporal sampling, <cite index="61-1">node and edge types that lack timestamps are sampled without temporal constraints applied</cite>.

Every edge type in schema r2 carries `edge_event_seq`, but carrying it is not the same as *declaring* it in the tg-gnn metadata. Any relation exported without a declared time attribute becomes a time-blind bridge, and a two-hop path `Card → Merchant_Category → Card` or `Party → Address → Party` then crosses the cutoff freely.

**Decision:** every exported relation must declare a time attribute. A relation that cannot is excluded from the export, not exported unconstrained. Phase 2 validation asserts `untimestamped_exported_relation_count == 0`.

### 3b. "At or before t" includes the seed's own edges

Temporal sampling admits elements at or before the seed timestamp. For a seed transaction, that set contains the seed's own card and merchant edges. Strict exclusion of the target is a separate step, not a consequence of temporal sampling.

### 3c. Target edges are message-passing edges by default in both major frameworks

For the Option A link-prediction arm this is the single highest-risk item. In PyG and DGL, <cite index="35-1">the edges being predicted remain present as message-passing edges during training</cite>, which produces overfitting and distribution shift at training time and, at test time, <cite index="35-1">implicit leakage through neighborhood aggregation</cite>.

The SpotTarget prescription: exclude all target edges at test time; at training time exclude at least those incident to a low-degree node <cite index="36-1">since excluding all training targets degrades performance substantially</cite>.

**The consequence specific to our schema:** r2 declares `WITH REVERSE_EDGE=` on every directed relation, including `Card_Merchant_Transaction`. Excluding a target edge without also excluding its reverse leaks the edge back in. GraphStorm requires <cite index="37-1">both `exclude_training_targets` and a `reverse_edge_types_map`</cite> for exactly this reason. R-GCN compounds it: the layer adds inverse edges and self-loops internally, so <cite index="40-1">edges must be dropped before the graph enters the layer, not after</cite>.

**Decision:** exclusion is specified as `(edge_type, reverse_edge_type)` pairs, never single types. Phase 2 validation asserts that for every excluded type, its `REVERSE_EDGE` counterpart is also excluded. This is a schema-driven check, since the reverse names are in the DDL.

### 3d. Residency recreates the transductive setting that fresh-instance removed by accident

The critique is current and specific to fraud under temporal shift. Transductive evaluation <cite index="63-1">makes the whole graph including every test node and its incident edges available during training, so gradients flow along paths connecting unlabelled test nodes to labelled training nodes</cite>. Inductive evaluation withholds test-period structure, and is <cite index="63-1">the setting a deployed fraud detector actually faces</cite>.

The widely-cited AWS reference implementation in this space is explicit that <cite index="64-1">its R-GCN is trained and tested transductively, with a learned embedding for each featureless node such as IP address</cite>. Two problems if we copy that: a learnable per-node ID embedding is a lookup table, so a test-period card absent from training has no embedding at all, and the model is free to memorise node identity.

**Decision:** the target setting is **inductive**. No learnable per-node ID embeddings. Every node's representation must be a function of its features and neighborhood, so an unseen 2019 card is scored by the same function as a 2016 one. Record this in §4 of `DECISIONS_DRAFT` as a model constraint, because it eliminates some architectures outright.

**Decision:** a training-fold export contains only topology below that fold's cutoff, so it is inductive by construction. Val/test exports contain topology up to the preceding boundary and the scored rows as seeds only. Residency in the database is fine; the *export* is where inductivity is reconstructed.

---

## D4. Replacement text for the no-pollution rule

Delete `DECISIONS_DRAFT.md` line 18 and substitute:

> **🚩 NO-LEAKAGE RULE — non-negotiable.** All splits are resident in one graph instance; separation is enforced by cutoff, not by absence.
>
> 1. **Rows.** Every stage trains on exactly the same training rows and evaluates on exactly the same test rows. Proven by matching `ordered_txn_id_hash`, not by row counts.
> 2. **Fitting.** No quantity fitted from data — projection edge, PageRank, community, aggregate, encoding, normalisation constant — may read an event at or after its snapshot's topology cutoff. Strict inequality.
> 3. **Traversal.** No message-passing path from any seed may reach an element at or after that seed's snapshot cutoff. Enforced by export-time edge masking, verified relation-by-relation, including reverse edges.
> 4. **Labels.** A label may enter a feature only once its availability timestamp precedes the consuming event. Applies to fraud proximity, target encodings and blocklist flags alike.
> 5. **Selection.** Hyperparameters are tuned on validation only. Arms differing in label cutoff are reported separately and never averaged.
>
> Violations of 1 are loud. Violations of 2, 3 and 4 are silent and *improve* the reported metric. They are found by the detection protocol in D7, not by inspection.

---

## D5. Link-prediction arm specifics (Stage 2, Option A)

Story 4e currently says "link prediction, NVIDIA-style" and stops there. Add:

- **Self-supervised.** The fraud label never enters the GNN. Embeddings are unsupervised structural summaries, joined to transaction rows for XGBoost afterwards. Story 4b's "decide which features go to the GNN" describes a *different*, supervised experiment. Both are legitimate; they are not one result and must not be reported as one.
- **Target and reverse exclusion** per D3c, as `(type, reverse_type)` pairs, applied before the graph enters the R-GCN layer.
- **Negative sampling needs a collision check.** Standard implementations frequently omit one, so <cite index="74-1">sampled negatives can coincide with real positive edges</cite>. On a card-merchant bipartite graph with heavy repeat structure this is common, not rare.
- **Negative regime is a reported hyperparameter, not a default.** Random negatives are often trivially separable; historical negatives, drawn from pairs that interacted previously but not in the current window, are the realistic setting <cite index="72-1">and force the model to distinguish genuinely inactive links from temporarily inactive ones</cite>. Report random and historical separately. A large gap between them is itself the finding.
- **Cost note:** `Card_Merchant_Transaction` with a per-transaction discriminator means this relation's cardinality equals the transaction count. Measure on a subsample before committing.

---

## D6. Temporal arm specifics (Stage 4)

Applies whichever temporal model Open item A resolves to, and is a hard requirement on the Story 6b feasibility spike.

- **Memory must be updated from prior batches only.** Updating memory with an interaction before predicting that interaction <cite index="46-1">causes information leakage, so the update uses messages from previous batches held in a raw message store</cite>. If tg-gnn's temporal example does not implement this, Story 6b fails and the model choice changes.
- **Reset memory and the neighbor loader at epoch start**, or state carries across epochs. <cite index="44-1">TGB's implementation resets both specifically to prevent temporal leakage.</cite>
- **Discard post-t memory updates at evaluation time.**
- **Batch size is a leakage-adjacent parameter.** Within a batch, all events see only prior-batch memory, so large batches coarsen temporal resolution below what the sampler advertises. Conservative rather than leaky, but it means a fraud burst inside one batch is invisible to itself. Report the batch size next to the metric.

---

## D7. Detection protocol: how we find out we were wrong

Static review cannot catch silent leakage. Four checks, all cheap, all mandatory before any number is reported.

1. **Null-structure dataset.** Regenerate with fraud independent of graph topology (`structure_correlated_fraud = FALSE`). Any graph lift there is pipeline leakage. This is the only *ground-truth* leak test available and it exists only because the dataset is generated. Highest value item in this document.
2. **Rewired arm R.** Degree-preserving rewire, identical marginals, destroyed structure. Catches activity-volume proxies that survive check 1.
3. **Ablate temporal features.** A disproportionate collapse when they are removed is a known leakage signature.
4. **Dev-versus-holdout gap.** A large gap between validation and a strictly later test window <cite index="24-1">is a conventional leakage indicator, with roughly 5 points cited as a threshold</cite>. Treat that figure as a heuristic, not a test: on ~0.1% positives it is within bootstrap noise, which is why AUCPR needs a confidence interval before any of these deltas is interpretable.

---

## D8. Schema deltas required (r3)

Mechanical, given the above.

1. `Payment_Transaction.visible_from_event_seq`, set equal to `event_seq` at load. Every traversal filters on this one field rather than on `split_id`, so the filter expression is identical for training folds, validation and test. A bug then fails loudly on training data instead of quietly on test data.
2. `Ctl_Feature_Snapshot.gnn_relation_allowlist STRING` — explicit, hand-authored, never auto-discovered.
3. `Ctl_Feature_Snapshot.excluded_target_relation_pairs STRING` — `(type, reverse_type)` pairs.
4. `Ctl_Feature_Snapshot.untimestamped_exported_relation_count UINT`, asserted zero in Phase 2.
5. `Ctl_Feature_Snapshot.negative_sampling_regime STRING` and `negative_collision_checked BOOL`.
6. `Ctl_Feature_Snapshot.is_inductive_export BOOL`, plus `learnable_id_embeddings_used BOOL` which must be FALSE.
7. Edge-level `train_mask` / `val_mask` / `test_mask` on relations entering the GNN export, following the GraphStorm pattern, since masking is per-edge and cannot be derived from a vertex attribute.
8. Phase 2 validation additions: for every excluded relation, its `REVERSE_EDGE` counterpart is also excluded; every exported relation declares a time attribute.

---

## D9. Retired

- **Open item C** (fresh-instance enforcement, "resolved"): retired. It answered row contamination only, which was never the leaking channel, and it made Stage 4 unimplementable.
- **Stories 4a, 5a, 6a** "prep clean training-ready state" and the zero-row verification query: deleted. Replace with "assert `Ctl_Pipeline_State.phase == IDLE` and run Phase 1 validation."
- **`training_ready_v1` snapshot/restore option**: retired with it.

## D10. Still open

- **Fold width.** Should match serving staleness, not compute budget. Blocked on choosing the split boundaries, which lost their justification when the dataset changed.
- **Option A versus B for the R-GCN target relation.** D5 specifies A. B remains undesigned and needs the four unanswered questions from `DOC_REVISIONS.md` §6 before it can be scheduled.
- **Whether the kit-parity arm K reports as a finding or a footnote.** Recommendation: finding.
